<div class="right_sidebar">
			<div class="wpmm-upgrade-banner">
              <img src="<?php echo APMM_IMG_DIR;?>/banner-image-pro.jpg" alt="upgrade-banner-top">
              <div class="wpmm-button-wrap-backend">
                <a href="http://demo.accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" class="wpmm-demo-btn" target="_blank">Demo</a>
                <a href="https://1.envato.market/c/1302794/275988/4415?u=https%3A%2F%2Fcodecanyon.net%2Fitem%2Fwp-mega-menu-pro-responsive-mega-menu-plugin-for-wordpress%2F19190840" target="_blank" class="wpmm-upgrade-btn">Upgrade</a>
                <a href="https://accesspressthemes.com/wordpress-plugins/wp-mega-menu-pro/" target="_blank" class="wpmm-upgrade-btn">Plugin Information</a>
              </div>
            <img src="<?php echo APMM_IMG_DIR;?>/banner-feature-pro.jpg" alt="upgrade-banner-bottom">
        </div>

</div>