
                <!----------------Social Icons settings  -------------------------->
		        <div class="apmm-slideToggle" id="socialicons_settings"  style="cursor:pointer;">
		          <div class="title_toggle"><?php _e('Social Icons Settings',APMM_TD);?></div>
		        </div>
		        <div class="apmm-Togglebox apmm-slideTogglebox_socialicons_settings" style="display: none;">

					<table cellspacing="0" class="widefat apmm_create_seciton">
						<tbody>
						    <tr>
						  		<td>
									<label><?php _e('Theme Title',APMM_TD);?></label>
								</td>
								<td>
									<input type="text" value="" class="apmm_theme_title" name="apmm_theme_settings['name']" />
								</td>
								                         
							</tr>
							<tr>
								<td>
									<label><?php _e('Theme Title',APMM_TD);?></label>
								</td>
								<td>
									<input type="text" value="" class="apmm_theme_title" name="apmm_theme_settings['name']" />
								</td>
							</tr>
							
					
						</tbody>
						</table>
		             </div>
                 <!----------------Social Icons settings End-------------------------->