<div class="arrow_section" style="display:none;">
     <label>Up Down Left Right</label>
<?php #if($i=1;$i<=7;$i++){?>
      <div class="arrow_type" id="arrow_type1" style="display:none;">
             <i class="fa fa-caret-up fa-3" aria-hidden="true"></i>
             <i class="fa fa-caret-down fa-3" aria-hidden="true"></i>
             <i class="fa fa-caret-left fa-3" aria-hidden="true"></i>
             <i class="fa fa-caret-right fa-3" aria-hidden="true"></i>
      </div>
	<div class="arrow_type" id="arrow_type2" style="display:none;">  
             <i class="fa fa-arrow-up fa-3" aria-hidden="true"></i>
             <i class="fa fa-arrow-down fa-3" aria-hidden="true"></i>
             <i class="fa fa-arrow-left fa-3" aria-hidden="true"></i>
             <i class="fa fa-arrow-right fa-3" aria-hidden="true"></i>
      </div>
      <div class="arrow_type" id="arrow_type3" style="display:none;">
             <i class="fa fa-chevron-up fa-3" aria-hidden="true"></i>
             <i class="fa fa-chevron-down fa-3" aria-hidden="true"></i>
             <i class="fa fa-chevron-left fa-3" aria-hidden="true"></i>
             <i class="fa fa-chevron-right fa-3" aria-hidden="true"></i>
      </div>
	<div class="arrow_type" id="arrow_type4" style="display:none;">
      	 <i class="fa fa-chevron-circle-up fa-3" aria-hidden="true"></i>
             <i class="fa fa-chevron-circle-down fa-3" aria-hidden="true"></i>
             <i class="fa fa-chevron-circle-left fa-3" aria-hidden="true"></i>
             <i class="fa fa-chevron-circle-right fa-3" aria-hidden="true"></i>
	</div>
	<div class="arrow_type" id="arrow_type5" style="display:none;">
             <i class="fa fa-arrow-circle-up fa-3" aria-hidden="true"></i>
             <i class="fa fa-arrow-circle-down fa-3" aria-hidden="true"></i>
             <i class="fa fa-arrow-circle-left fa-3" aria-hidden="true"></i>
             <i class="fa fa-arrow-circle-right fa-3" aria-hidden="true"></i>
	</div>
	<div class="arrow_type" id="arrow_type6" style="display:none;">
      	 <i class="fa fa-angle-double-up fa-3" aria-hidden="true"></i>
             <i class="fa fa-angle-double-down fa-3" aria-hidden="true"></i>
             <i class="fa fa-angle-double-left fa-3" aria-hidden="true"></i>
             <i class="fa fa-angle-double-right fa-3" aria-hidden="true"></i>
	</div>
	<div class="arrow_type" id="arrow_type7" style="display:none;">
		<i class="fa fa-hand-o-up fa-3" aria-hidden="true"></i>
            <i class="fa fa-hand-o-down fa-3" aria-hidden="true"></i>
            <i class="fa fa-hand-o-left fa-3" aria-hidden="true"></i>
            <i class="fa fa-hand-o-right fa-3" aria-hidden="true"></i>
	</div>
 <?php #} ?>
</div> 