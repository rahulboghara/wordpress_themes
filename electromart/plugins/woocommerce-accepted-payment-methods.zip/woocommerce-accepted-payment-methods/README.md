WooCommerce Accepted Payment Methods
====================================

Extends WooCommerce giving you the option to display accepted payment methods via widget, shortcode or template tag.