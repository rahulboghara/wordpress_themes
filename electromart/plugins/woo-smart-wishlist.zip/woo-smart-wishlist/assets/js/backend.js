jQuery( document ).ready( function( $ ) {
	$( '.woosw_color_picker' ).wpColorPicker();
} );