<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '1120d0c8ce980ef2d5868a4e384db5019b3f53f3';

}
