<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Countdown_Widget' );


	class TribeCountdownWidget extends Tribe__Events__Pro__Countdown_Widget {

	}