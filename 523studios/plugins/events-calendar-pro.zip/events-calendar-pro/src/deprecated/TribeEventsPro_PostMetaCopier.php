<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Pro__Post_Meta_Copier' );


	class TribeEventsPro_PostMetaCopier extends Tribe__Events__Pro__Post_Meta_Copier {

	}