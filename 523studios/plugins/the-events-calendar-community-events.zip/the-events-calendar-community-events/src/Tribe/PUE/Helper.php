<?php

class Tribe__Events__Community__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '';

}
