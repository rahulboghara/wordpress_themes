<?php
/*
Plugin Name: All Pms
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying All pms.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 *  All Pms
 */

if ( ! defined( 'ABSPATH' ) ) die( 'Accessing this file directly is denied.' );

if (!class_exists('All_pms')){
    class All_pms{

        public function __construct()
        {   
        	$this->_define_constant();
            // now lets include all the required files
            $this->_include();

            add_action('admin_enqueue_scripts', array($this, 'all_pms_scripts'));
            add_filter('wp_nav_menu_args', array($this, 'zs_mega_menu_args'), 10000);
            add_action('admin_menu', array($this, 'remove_menu_items'));
        }

        function remove_menu_items() {
		    if( !current_user_can( 'tenants' ) ):
		        remove_menu_page( 'edit.php?post_type=doc_upload' );
		        remove_menu_page( 'edit.php?post_type=maintenance_user' );
		        remove_menu_page( 'edit.php?post_type=rent' );

		    endif;
		}
		function all_pms_scripts() {

		    wp_enqueue_script( 'jquery-ui-datepicker' );
		    wp_enqueue_style( 'jquery-ui-style', '//ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/smoothness/jquery-ui.css', true);
		    wp_enqueue_script( 'custom', plugin_dir_url( __FILE__ ) . 'js/custom.js', array(), '', true );
		}

		private function _define_constant()
        {
            if( ! defined( 'All_PMS_PATH' ) ) define( 'All_PMS_PATH', plugin_dir_path( __FILE__ ) );
        }

		private function _include()
        {
			require All_PMS_PATH . 'include/property_pms/property_pms.php';
			require All_PMS_PATH . 'include/tenants_pms/tenants_pms.php';
			require All_PMS_PATH . 'include/payment_pms/payment_pms.php';
			require All_PMS_PATH . 'include/expenses_pms/expenses_pms.php';
			require All_PMS_PATH . 'include/maintenance_pms/maintenance_pms.php';
			require All_PMS_PATH . 'include/rent_pms/rent_pms.php';
			require All_PMS_PATH . 'include/user_maintenance/user_maintenance.php';
			require All_PMS_PATH . 'include/file_upload/file_upload.php';
		}
    }
}
new All_pms();



