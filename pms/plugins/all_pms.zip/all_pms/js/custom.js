jQuery(document).ready(function(){
jQuery('#payment_cq_date').datepicker({
dateFormat : 'dd-mm-yy'
});

jQuery('#maintenance_rq_date').datepicker({
  dateFormat : 'dd-mm-yy'
  });
});

