<?php

/**
 * Custom property post
 */

function property_post_type (){
	
	$labels = array(
		'name' => 'Property',
		'singular_name' => 'property',
		'add_new' => 'Add New Property',
		'all_items' => 'All Property',
		'add_new_item' => 'Add Property',
		'edit_item' => 'Edit Property',
		'new_item' => 'New Property',
		'view_item' => 'View Property',
		'search_item' => 'Search Property',
		'not_found' => 'No Property found',
		'not_found_in_trash' => 'No Property found in trash',
		'parent_item_colon' => 'Parent Property'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-admin-home',
		'supports' => array(
			'title',
			'thumbnail',
		),
        'taxonomies' => array('property_type'),
        'menu_position' => 15,
        'exclude_from_search' => false
    );
	register_post_type('property',$args);
    property_register_taxonomies();
}
add_action('init','property_post_type');



//Register Taxonomies
function property_register_taxonomies() {
    register_taxonomy(
        'property_type', 'property', 
        array(
            'labels'                => array(
                'name'                  => __( 'Property Type', 'pms' ),
                'singular_name'         => __( 'Property Type', 'pms' ),
                'search_items'          => __( 'Search Property Type', 'pms' ),
                'popular_items'         => __( 'Popular Property Type', 'pms' ),
                'all_items'             => __( 'All Property Type', 'pms' ),
                'parent_item'           => __( 'Parent Property Type', 'pms' ),
                'parent_item_colon'     => __( 'Parent Property Type:', 'pms' ),
                'edit_item'             => __( 'Edit Property Type', 'pms' ), 
                'update_item'           => __( 'Update Property Type', 'pms' ),
                'add_new_item'          => __( 'Add New Property Type', 'pms' ),
                'new_item_name'         => __( 'New Property Type', 'pms' ),
                'menu_name'             => __( 'Property Type', 'pms' ),
                'not_found'             => __( 'No Property Type found', 'pms' ),
                'not_found_in_trash'    => __( 'No Property Type found in trash', 'pms' ),
            ), 
            'hierarchical' => true, 
            'label' => 'Property Type',
            'show_admin_column' => true, 
            'query_var' => true, 
            'rewrite' => array('slug' => 'property-type')
        )
    );
    if (count(get_terms('property_type', 'hide_empty=0')) == 0) {
        register_taxonomy('type', 'property', array('hierarchical' => true, 'label' => 'Property Type'));
        $_categories = get_categories('taxonomy=type&title_li=');
        foreach ($_categories as $_cat) {
            if (!term_exists($_cat->name, 'property_type'))
                wp_insert_term($_cat->name, 'property_type');
        }
        $property = new WP_Query(array('post_type' => 'property', 'posts_per_page' => '-1'));
        while ($property->have_posts()) : $property->the_post();
            $post_id = get_the_ID();
            $_terms = wp_get_post_terms($post_id, 'type');
            $terms = array();
            foreach ($_terms as $_term) {
                $terms[] = $_term->term_id;
            }
            wp_set_post_terms($post_id, $terms, 'property_type');
        endwhile;
        wp_reset_query();
        register_taxonomy('type', array());
    } 
}

function display_property_meta_box( $property ) {
    $property_address = esc_html( get_post_meta( $property->ID, 'property_address', true ) );
    $property_owner = esc_html( get_post_meta( $property->ID, 'property_owner', true ) );
    $property_owner_address = esc_html( get_post_meta( $property->ID, 'property_owner_address', true ) );
    $property_owner_phone = esc_html( get_post_meta( $property->ID, 'property_owner_phone', true ) );
    $property_owner_email = esc_html( get_post_meta( $property->ID, 'property_owner_email', true ) );
    $property_fees = esc_html( get_post_meta( $property->ID, 'property_fees', true ) );
    $property_deposit = esc_html( get_post_meta( $property->ID, 'property_deposit', true ) );
    $monthly_rent = esc_html( get_post_meta( $property->ID, 'monthly_rent', true ) );
    $one_time_late_rent_fee = esc_html( get_post_meta( $property->ID, 'one_time_late_rent_fee', true ) );
    $recurring_late_rent_fee = esc_html( get_post_meta( $property->ID, 'recurring_late_rent_fee', true ) );
    $one_time_selected = esc_html( get_post_meta( $property->ID, 'one_time_selected', true ) );
    $recurring_selected = esc_html( get_post_meta( $property->ID, 'recurring_selected', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 200px">Property Address</td>
            <td><input type="text" size="80" name="property_address" value="<?php echo esc_attr($property_address); ?>" required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Property Owner</td>
            <td><input type="text" size="80" name="property_owner" value="<?php echo esc_attr($property_owner); ?>" required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Property Owner Address</td>
            <td><input type="text" size="80" name="property_owner_address" value="<?php echo esc_attr($property_owner_address); ?>" required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Property Owner Phone</td>
            <td><input type="number" class="number_width" size="10"  name="property_owner_phone" value="<?php echo esc_attr($property_owner_phone); ?>" required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Property Owner Email</td>
            <td><input type="email" size="80" name="property_owner_email" value="<?php echo esc_attr($property_owner_email); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Property Fees</td>
            <td><input type="number" class="number_width" size="80" name="property_fees" value="<?php echo esc_attr($property_fees); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Monthly rent</td>
            <td><input type="number" class="number_width" size="80" name="monthly_rent" value="<?php echo esc_attr($monthly_rent); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Move-in Deposit</td>
            <td><input type="number" class="number_width" size="80" name="property_deposit" value="<?php echo esc_attr($property_deposit); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">One-Time Late Rent Fee</td>
            <td>
                <select name="one_time_selected" class="form-control form-control-user" value="<?php echo esc_attr($one_time_selected); ?>">
                    <?php
                    if ($one_time_selected != '') {
                        ?>
                        <option value="<?php echo esc_attr($one_time_selected); ?>" hidden><?php echo esc_attr($one_time_selected); ?></option>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Late Rent Fee')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="FlatRate">FlatRate</option>
                    <option value="Percentage">Percentage</option>
                </select>
            </td>
        </tr>  
        <tr>
            <td style="width: 200px">Recurring Late Rent Fee</td>
            <td>
                <select name="recurring_selected" class="form-control" value="<?php echo esc_attr($recurring_selected); ?>">
                    <?php
                    if ($recurring_selected != '') {
                        ?>
                        <option value="<?php echo esc_attr($recurring_selected); ?>" hidden><?php echo esc_attr($recurring_selected); ?></option>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Late Rent Fee')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="FlatRate">FlatRate</option>
                    <option value="Percentage">Percentage</option>
                </select>
            </td>
        </tr> 

        <script type="text/javascript">
            jQuery(document).ready(function() {

                jQuery('[name="one_time_selected"]').change(function() {
                    jQuery('[name="one_time_selected"]').find('option').prop('disabled',false);

                    if (jQuery('[name="one_time_selected"]').val() === "FlatRate") {
                        jQuery('<input type="number" name="one_time_late_rent_fee" class="input-flat" placeholder="Flat Rate" value="<?php echo esc_attr($one_time_late_rent_fee); ?>">').insertAfter('[name="one_time_selected"]');
                        jQuery('.input-percentage').remove();
                        jQuery('.calc-percentage').remove();
                        jQuery('.input-flat').on('input', function () { 
                          var monthly_rent_new = parseFloat(jQuery('[name="monthly_rent"]').val());
                          var value = jQuery(this).val();      
                          if (value !== '') {        
                              jQuery(this).val(Math.max(Math.min(value, monthly_rent_new), 0));
                          }
                      });
                    } else if (jQuery('[name="one_time_selected"]').val() === "Percentage"){
                        jQuery('<input type="number" name="calc_percentage" class="calc-percentage" placeholder="Percentage">').insertAfter('[name="one_time_selected"]');

                        jQuery('<input type="number" name="one_time_late_rent_fee" class="input-percentage" placeholder="Percentage By Fee" value="<?php echo esc_attr($one_time_late_rent_fee); ?>" readonly>').insertAfter('.calc-percentage');
                        jQuery('.input-flat').remove();
                        jQuery('.calc-percentage').keyup(function(){
                            var monthly_rent;
                            var input_percentage;

                            monthly_rent = parseFloat(jQuery('[name="monthly_rent"]').val());
                            input_percentage = parseFloat(jQuery('.calc-percentage').val());

                            var result =  (input_percentage / 100) * monthly_rent;
                            var result_final = (isNaN(result)) ? 0 : result;
                            jQuery('.input-percentage').val(result_final.toFixed(0));
                        });

                        jQuery('.calc-percentage').on('input', function () { 
                          var value = jQuery(this).val();      
                          if ((value !== '')) {        
                              jQuery(this).val(Math.max(Math.min(value, 100), 0));
                          }
                      });
                        var monthly_rent_old;
                        var input_percentage_old;

                        monthly_rent_old = parseFloat(jQuery('[name="monthly_rent"]').val());
                        input_percentage_old = parseFloat(jQuery('[name="one_time_late_rent_fee"]').val());

                        var result =  (input_percentage_old * 100 / monthly_rent_old);
                        var result_final = (isNaN(result)) ? 0 : result;
                        jQuery('.calc-percentage').val(result_final.toFixed(0));
                    }
                });

                jQuery(window).load(function() {
                    if (jQuery('[name="one_time_selected"]').val() === "FlatRate") {
                        jQuery('<input type="number" name="one_time_late_rent_fee" class="input-flat" placeholder="Flat Rate" value="<?php echo esc_attr($one_time_late_rent_fee); ?>">').insertAfter('[name="one_time_selected"]');
                        jQuery('.input-percentage').remove();
                        jQuery('.calc-percentage').remove();
                        jQuery('.input-flat').on('input', function () { 
                          var monthly_rent_new = parseFloat(jQuery('[name="monthly_rent"]').val());
                          var value = jQuery(this).val();      
                          if (value !== '') {        
                              jQuery(this).val(Math.max(Math.min(value, monthly_rent_new), 0));
                          }
                      });

                    } else if (jQuery('[name="one_time_selected"]').val() === "Percentage") {
                        jQuery('<input type="number" name="calc_percentage" class="calc-percentage" placeholder="Percentage">').insertAfter('[name="one_time_selected"]');
                        jQuery('<input type="number" name="one_time_late_rent_fee" class="input-percentage" placeholder="Percentage By Fee" value="<?php echo esc_attr($one_time_late_rent_fee); ?>" readonly>').insertAfter('.calc-percentage');
                        jQuery('.input-flat').remove();
                        var monthly_rent_old;
                        var input_percentage_old;

                        monthly_rent_old = parseFloat(jQuery('[name="monthly_rent"]').val());
                        input_percentage_old = parseFloat(jQuery('[name="one_time_late_rent_fee"]').val());

                        var result =  (input_percentage_old * 100 / monthly_rent_old);
                        var result_final = (isNaN(result)) ? 0 : result;
                        jQuery('.calc-percentage').val(result_final.toFixed(0));


                        jQuery('.calc-percentage').keyup(function(){
                            var monthly_rent;
                            var input_percentage;

                            monthly_rent = parseFloat(jQuery('[name="monthly_rent"]').val());
                            input_percentage = parseFloat(jQuery('.calc-percentage').val());

                            var result =  (input_percentage / 100) * monthly_rent;
                            var result_final = (isNaN(result)) ? 0 : result;
                            jQuery('.input-percentage').val(result_final.toFixed(0));
                        });
                    }
                    var one_time = jQuery('[name="one_time_selected"]').val();      
                    if (one_time === 'FlatRate' || one_time === 'Percentage') {   
                        var val = jQuery('[name="one_time_selected"] option:selected').val();
                        jQuery('[name="one_time_selected"]').find('option[value='+val+']').prop('disabled',true);
                    }
                });

                jQuery('.calc-percentage').keyup(function(){
                    var monthly_rent;
                    var input_percentage;

                    monthly_rent = parseFloat(jQuery('[name="monthly_rent"]').val());
                    input_percentage = parseFloat(jQuery('.calc-percentage').val());

                    var result =  (input_percentage / 100) * monthly_rent;
                    var result_final = (isNaN(result)) ? 0 : result;
                    jQuery('.input-percentage').val(result_final.toFixed(0));
                });

                jQuery('.calc-percentage').on('input', function () { 
                  var value = jQuery(this).val();      
                  if ((value !== '')) {        
                      jQuery(this).val(Math.max(Math.min(value, 100), 0));
                  }
              });

                jQuery('.input-flat').on('input', function () { 
                  var monthly_rent_new = parseFloat(jQuery('[name="monthly_rent"]').val());
                  var value = jQuery(this).val();      
                  if (value !== '') {        
                      jQuery(this).val(Math.max(Math.min(value, monthly_rent_new), 0));
                  }
              });

            });

            //Recurring Late Rent Fee
                jQuery(document).ready(function() {
                jQuery('[name="recurring_selected"]').change(function() {
                    jQuery('[name="recurring_selected"]').find('option').prop('disabled',false);

                    if (jQuery('[name="recurring_selected"]').val() == "FlatRate") {
                        jQuery('<input type="number" name="recurring_late_rent_fee" class="r-input-flat" placeholder="Flat Rate" value="<?php echo esc_attr($recurring_late_rent_fee); ?>">').insertAfter('[name="recurring_selected"]');
                        jQuery('.r-input-percentage').remove();
                        jQuery('.r-calc-percentage').remove();
                        jQuery('.r-input-flat').on('input', function () { 
                          var monthly_rent_new = parseFloat(jQuery('[name="monthly_rent"]').val());
                          var value = jQuery(this).val();      
                          if (value !== '') {        
                              jQuery(this).val(Math.max(Math.min(value, monthly_rent_new), 0));
                          }
                      });
                    } else if (jQuery('[name="recurring_selected"]').val() == "Percentage"){
                        jQuery('<input type="number" name="r_calc_percentage" class="r-calc-percentage" placeholder="Percentage">').insertAfter('[name="recurring_selected"]');

                        jQuery('<input type="number" name="recurring_late_rent_fee" class="r-input-percentage" placeholder="Percentage By Fee" value="<?php echo esc_attr($recurring_late_rent_fee); ?>" readonly>').insertAfter('.r-calc-percentage');
                        jQuery('.r-input-flat').remove();
                        jQuery('.r-calc-percentage').keyup(function(){
                            var monthly_rent;
                            var input_percentage;

                            monthly_rent = parseFloat(jQuery('[name="monthly_rent"]').val());
                            input_percentage = parseFloat(jQuery('.r-calc-percentage').val());

                            var result =  (input_percentage / 100) * monthly_rent;
                            var result_final = (isNaN(result)) ? 0 : result;
                            jQuery('.r-input-percentage').val(result_final.toFixed(0));
                        });

                        jQuery('.r-calc-percentage').on('input', function () { 
                          var value = jQuery(this).val();      
                          if ((value !== '')) {        
                              jQuery(this).val(Math.max(Math.min(value, 100), 0));
                          }
                      });
                        var monthly_rent_old;
                        var input_percentage_old;

                        monthly_rent_old = parseFloat(jQuery('[name="monthly_rent"]').val());
                        input_percentage_old = parseFloat(jQuery('[name="recurring_late_rent_fee"]').val());

                        var result =  (input_percentage_old * 100 / monthly_rent_old);
                        var result_final = (isNaN(result)) ? 0 : result;
                        jQuery('.r-calc-percentage').val(result_final.toFixed(0));
                    }
                });
                jQuery(window).load(function() {
                    if (jQuery('[name="recurring_selected"]').val() == "FlatRate") {
                        jQuery('<input type="number" name="recurring_late_rent_fee" class="r-input-flat" placeholder="Flat Rate" value="<?php echo esc_attr($recurring_late_rent_fee); ?>">').insertAfter('[name="recurring_selected"]');
                        jQuery('.r-input-percentage').remove();
                        jQuery('.r-calc-percentage').remove();
                        jQuery('.r-input-flat').on('input', function () { 
                          var monthly_rent_new = parseFloat(jQuery('[name="monthly_rent"]').val());
                          var value = jQuery(this).val();      
                          if (value !== '') {        
                              jQuery(this).val(Math.max(Math.min(value, monthly_rent_new), 0));
                          }
                      });

                    } else if (jQuery('[name="recurring_selected"]').val() == "Percentage") {
                        jQuery('<input type="number" name="r_calc_percentage" class="r-calc-percentage" placeholder="Percentage">').insertAfter('[name="recurring_selected"]');
                        jQuery('<input type="number" name="recurring_late_rent_fee" class="r-input-percentage" placeholder="Percentage By Fee" value="<?php echo esc_attr($recurring_late_rent_fee); ?>" readonly>').insertAfter('.r-calc-percentage');
                        jQuery('.r-input-flat').remove();
                        var monthly_rent_old;
                        var input_percentage_old;

                        monthly_rent_old = parseFloat(jQuery('[name="monthly_rent"]').val());
                        input_percentage_old = parseFloat(jQuery('[name="recurring_late_rent_fee"]').val());

                        var result =  (input_percentage_old * 100 / monthly_rent_old);
                        var result_final = (isNaN(result)) ? 0 : result;
                        jQuery('.r-calc-percentage').val(result_final.toFixed(0));


                        jQuery('.r-calc-percentage').keyup(function(){
                            var monthly_rent;
                            var input_percentage;

                            monthly_rent = parseFloat(jQuery('[name="monthly_rent"]').val());
                            input_percentage = parseFloat(jQuery('.r-calc-percentage').val());

                            var result =  (input_percentage / 100) * monthly_rent;
                            var result_final = (isNaN(result)) ? 0 : result;
                            jQuery('.r-input-percentage').val(result_final.toFixed(0));
                        });
                    }

                    var r_time = jQuery('[name="recurring_selected"]').val(); 
                    if (r_time === 'FlatRate' || r_time === 'Percentage') {   
                        var val = jQuery('[name="recurring_selected"] option:selected').val();
                        jQuery('[name="recurring_selected"]').find('option[value='+val+']').prop('disabled',true);
                    }
                });
                jQuery('.r-calc-percentage').keyup(function(){
                    var monthly_rent;
                    var input_percentage;

                    monthly_rent = parseFloat(jQuery('[name="monthly_rent"]').val());
                    input_percentage = parseFloat(jQuery('.r-calc-percentage').val());

                    var result =  (input_percentage / 100) * monthly_rent;
                    var result_final = (isNaN(result)) ? 0 : result;
                    jQuery('.r-input-percentage').val(result_final.toFixed(0));
                });
                jQuery('.r-calc-percentage').on('input', function () {
                  var value = jQuery(this).val();      
                  if ((value !== '')) {        
                      jQuery(this).val(Math.max(Math.min(value, 100), 0));
                  }
                });
                jQuery('.r-input-flat').on('input', function () {
                  var monthly_rent_new = parseFloat(jQuery('[name="monthly_rent"]').val());
                  var value = jQuery(this).val();      
                  if (value !== '') {        
                      jQuery(this).val(Math.max(Math.min(value, monthly_rent_new), 0));
                  }
                });
                });
        </script>  
    </table>
    <?php
}

function property_pms_admin() {
    add_meta_box( 'property_meta_box',
        'Property Details',
        'display_property_meta_box',
        'property', 'normal', 'high'
    );
}

add_action( 'admin_init', 'property_pms_admin' );


function save_property_fields( $property_id, $property ) {
    // Check post type for Property
    if ( $property->post_type == 'property' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['property_address'] ) && $_POST['property_address'] != '' ) {
            update_post_meta( $property_id, 'property_address', $_POST['property_address'] );
        }
        if ( isset( $_POST['property_owner'] ) && $_POST['property_owner'] != '' ) {
            update_post_meta( $property_id, 'property_owner', $_POST['property_owner'] );
        }
        if ( isset( $_POST['property_owner_address'] ) && $_POST['property_owner_address'] != '' ) {
            update_post_meta( $property_id, 'property_owner_address', $_POST['property_owner_address'] );
        }
        if ( isset( $_POST['property_owner_phone'] ) && $_POST['property_owner_phone'] != '' ) {
            update_post_meta( $property_id, 'property_owner_phone', $_POST['property_owner_phone'] );
        }
        if ( isset( $_POST['property_owner_email'] ) && $_POST['property_owner_email'] != '' ) {
            update_post_meta( $property_id, 'property_owner_email', $_POST['property_owner_email'] );
        }
        if ( isset( $_POST['property_fees'] ) && $_POST['property_fees'] != '' ) {
            update_post_meta( $property_id, 'property_fees', $_POST['property_fees'] );
        }
        if ( isset( $_POST['property_deposit'] ) && $_POST['property_deposit'] != '' ) {
            update_post_meta( $property_id, 'property_deposit', $_POST['property_deposit'] );
        }
        if ( isset( $_POST['monthly_rent'] ) && $_POST['monthly_rent'] != '' ) {
            update_post_meta( $property_id, 'monthly_rent', $_POST['monthly_rent'] );
        }
        if ( isset( $_POST['one_time_late_rent_fee'] ) && $_POST['one_time_late_rent_fee'] != '' ) {
            update_post_meta( $property_id, 'one_time_late_rent_fee', $_POST['one_time_late_rent_fee'] );
        }
        if ( isset( $_POST['one_time_selected'] ) && $_POST['one_time_selected'] != '' ) {
            update_post_meta( $property_id, 'one_time_selected', $_POST['one_time_selected'] );
        }
        if ( isset( $_POST['recurring_selected'] ) && $_POST['recurring_selected'] != '' ) {
            update_post_meta( $property_id, 'recurring_selected', $_POST['recurring_selected'] );
        }
        if ( isset( $_POST['recurring_late_rent_fee'] ) && $_POST['recurring_late_rent_fee'] != '' ) {
            update_post_meta( $property_id, 'recurring_late_rent_fee', $_POST['recurring_late_rent_fee'] );
        }
    }
}

add_action( 'save_post', 'save_property_fields', 10, 2 );


