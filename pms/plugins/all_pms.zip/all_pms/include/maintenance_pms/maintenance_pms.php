<?php
/**
 * Custom Maintenance Requests
 */

function maintenance_post_type (){
	
	$labels = array(
		'name' => 'Maintenance Requests',
		'singular_name' => 'maintenance',
		'add_new' => 'Add New Maintenance Requests',
		'all_items' => 'All Maintenance Requests',
		'add_new_item' => 'Add Maintenance Requests',
		'edit_item' => 'Edit Maintenance Requests',
		'new_item' => 'New Maintenance Requests',
		'view_item' => 'View Maintenance Requests',
		'search_item' => 'Search Maintenance Requests',
		'not_found' => 'No Maintenance Requests found',
		'not_found_in_trash' => 'No Maintenance Requests found in trash',
		'parent_item_colon' => 'Parent Maintenance Requests'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' =>  'data:image/svg+xml;base64,' . base64_encode(
            file_get_contents( plugin_dir_url( __FILE__ ) . 'img/logo.svg' )
        ),
		'supports' => array(
			'title',
		),
        'menu_position' => 15,
        'exclude_from_search' => false
    );
	register_post_type('maintenance',$args);
}
add_action('init','maintenance_post_type');



function display_maintenance_meta_box( $maintenance ) {
    $maintenance_rq_name = esc_html( get_post_meta( $maintenance->ID, 'maintenance_rq_name', true ) );
    $maintenance_rq_desc = esc_html( get_post_meta( $maintenance->ID, 'maintenance_rq_desc', true ) );
    $maintenance_rq_amount = esc_html( get_post_meta( $maintenance->ID, 'maintenance_rq_amount', true ) );
    $maintenance_rq_date = esc_html( get_post_meta( $maintenance->ID, 'maintenance_rq_date', true ) );
    $maintenance_rq_status = esc_html( get_post_meta( $maintenance->ID, 'maintenance_rq_status', true ) );
    

    ?>
    <table>
        <tr>
            <td style="width: 200px">Maintenance Name</td>
            <td><input type="text" size="80" name="maintenance_rq_name" placeholder="Enter Maintenance Name" value="<?php echo esc_attr($maintenance_rq_name); ?>"  required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Maintenance Description</td>
            <td><textarea name="maintenance_rq_desc" placeholder="Enter Maintenance Description"/><?php echo esc_attr($maintenance_rq_desc); ?></textarea></td>
        </tr>
        <tr>
            <td style="width: 200px">Maintenance Amount</td>
            <td><input type="number" class="number_width" size="80" placeholder="Enter Maintenance Amount" name="maintenance_rq_amount" value="<?php echo esc_attr($maintenance_rq_amount); ?>" required/></td>
        </tr>
            <td style="width: 200px">Maintenance Date</td>
            <td><input type="text" name="maintenance_rq_date" id="maintenance_rq_date" placeholder="Enter Maintenance Date" value="<?php echo esc_attr($maintenance_rq_date); ?>"></td>            
        <tr>
            <td style="width: 200px">Select Maintenance Status</td>
            <td>
                <select name="maintenance_rq_status" value="<?php echo esc_attr($maintenance_rq_status); ?>">
                    <?php
                    if ($maintenance_rq_status != '') {
                        ?>
                        <option value="<?php echo esc_attr($maintenance_rq_status); ?>" hidden><?php echo esc_attr($maintenance_rq_status); ?></option>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Maintenance Status')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="Pending">Pending</option>
                    <option value="Complete">Complete</option>

                </select>
            </td>
        </tr>  
    </table>
    <?php
}

function maintenance_pms_admin() {
    add_meta_box( 'maintenance_meta_box',
        'Maintenance Requests Details',
        'display_maintenance_meta_box',
        'maintenance', 'normal', 'high'
    );
}

add_action( 'admin_init', 'maintenance_pms_admin' );


function save_maintenance_fields( $maintenance_rq_id, $maintenance ) {
    // Check post type for maintenance
    if ( $maintenance->post_type == 'maintenance' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['maintenance_rq_name'] ) && $_POST['maintenance_rq_name'] != '' ) {
            update_post_meta( $maintenance_rq_id, 'maintenance_rq_name', $_POST['maintenance_rq_name'] );
        }
        if ( isset( $_POST['maintenance_rq_desc'] ) && $_POST['maintenance_rq_desc'] != '' ) {
            update_post_meta( $maintenance_rq_id, 'maintenance_rq_desc', $_POST['maintenance_rq_desc'] );
        }
        if ( isset( $_POST['maintenance_rq_amount'] ) && $_POST['maintenance_rq_amount'] != '' ) {
            update_post_meta( $maintenance_rq_id, 'maintenance_rq_amount', $_POST['maintenance_rq_amount'] );
        }
        if ( isset( $_POST['maintenance_rq_date'] ) && $_POST['maintenance_rq_date'] != '' ) {
            update_post_meta( $maintenance_rq_id, 'maintenance_rq_date', $_POST['maintenance_rq_date'] );
        }
        if ( isset( $_POST['maintenance_rq_status'] ) && $_POST['maintenance_rq_status'] != '' ) {
            update_post_meta( $maintenance_rq_id, 'maintenance_rq_status', $_POST['maintenance_rq_status'] );
        }


    }
}

add_action( 'save_post', 'save_maintenance_fields', 10, 2 );

function add_maintenance_columns($columns) {
    return array_merge($columns,
              array('maintenance_status' => __('Maintenance Status'),
                    'maintenance_date' =>__( 'Maintenance Date')));
}
add_filter('manage_maintenance_posts_columns' , 'add_maintenance_columns');


function custom_maintenance_column( $column ) {
    global $post;
    switch ( $column ) {
        case 'maintenance_date':
        echo get_post_meta( $post->ID , 'maintenance_rq_date' , true );
        break;

      case 'maintenance_status':
        echo get_post_meta( $post->ID , 'maintenance_rq_status' , true );
        break;
    }
}
add_action( 'manage_maintenance_posts_custom_column' , 'custom_maintenance_column', 10, 2     );


// Register the column as sortable
function register_sortable_columns( $columns ) {
    $columns['maintenance_status'] = 'Maintenance Status';
    $columns['maintenance_date'] = 'Maintenance Date';
    return $columns;
}
add_filter( 'manage_edit-maintenance_sortable_columns', 'register_sortable_columns' );