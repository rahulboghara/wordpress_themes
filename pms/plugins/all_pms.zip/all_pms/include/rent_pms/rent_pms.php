<?php

/**
 * Custom Rent post
 */

function rent_post_type (){
	
	$labels = array(
		'name' => 'Pay Rent',
		'singular_name' => 'rent',
		'add_new' => 'Add New Pay Rent',
		'all_items' => 'All Pay Rent',
		'add_new_item' => 'Add Pay Rent',
		'edit_item' => 'Edit Pay Rent',
		'new_item' => 'New Pay Rent',
		'view_item' => 'View Pay Rent',
		'search_item' => 'Search Pay Rent',
		'not_found' => 'No Pay Rent found',
		'not_found_in_trash' => 'No Pay Rent found in trash',
		'parent_item_colon' => 'Parent Pay Rent'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
        'capability_type' => array('rent','rents','post'),
        'map_meta_cap' => true,
		'hierarchical' => false,
		'menu_icon' =>  'data:image/svg+xml;base64,' . base64_encode(
            file_get_contents( plugin_dir_url( __FILE__ ) . 'img/rent.svg' )
        ),
		'supports' => array(
			'title',
		),
        'menu_position' => 17,
        'exclude_from_search' => false
    );
	register_post_type('rent',$args);
}
add_action('init','rent_post_type');


add_action( 'init', 'rent_caps');

function rent_caps() {
    global $wp_roles;

    if ( isset($wp_roles) ) {
        $wp_roles->add_cap( 'tenants', 'edit_rent' );
        $wp_roles->add_cap( 'tenants', 'read_rent' );
        $wp_roles->add_cap( 'tenants', 'delete_rent' );
        $wp_roles->add_cap( 'tenants', 'publish_rents' );
        $wp_roles->add_cap( 'tenants', 'edit_rents' );
        $wp_roles->add_cap( 'tenants', 'edit_others_rents' );
        $wp_roles->add_cap( 'tenants', 'delete_rents' );
        $wp_roles->add_cap( 'tenants', 'delete_others_rents' );
        $wp_roles->add_cap( 'tenants', 'read_private_rents' );

        $wp_roles->add_cap( 'administrator', 'edit_rent' );
        $wp_roles->add_cap( 'administrator', 'read_rent' );
        $wp_roles->add_cap( 'administrator', 'delete_rent' );
        $wp_roles->add_cap( 'administrator', 'publish_rents' );
        $wp_roles->add_cap( 'administrator', 'edit_rents' );
        $wp_roles->add_cap( 'administrator', 'edit_others_rents' );
        $wp_roles->add_cap( 'administrator', 'delete_rents' );
        $wp_roles->add_cap( 'administrator', 'delete_others_rents' );
        $wp_roles->add_cap( 'administrator', 'read_private_rents' );

    }
}
    

function display_rent_meta_box( $rent ) {
    $rent_cash_amount = esc_html( get_post_meta( $rent->ID, 'rent_cash_amount', true ) );
    $rent_cheque_bank_name = esc_html( get_post_meta( $rent->ID, 'rent_cheque_bank_name', true ) );
    $rent_cheque_acc_no = esc_html( get_post_meta( $rent->ID, 'rent_cheque_acc_no', true ) );
    $rent_cheque_number = esc_html( get_post_meta( $rent->ID, 'rent_cheque_number', true ) );
    $rent_cheque_acc_name = esc_html( get_post_meta( $rent->ID, 'rent_cheque_acc_name', true ) );
    $rent_selected = esc_html( get_post_meta( $rent->ID, 'rent_selected', true ) );
    ?>
    <table>
        <tr class="select_tr">
            <td style="width: 200px">Pay Rent</td>
            <td>
                <select name="rent_selected" class="form-control form-control-user" value="<?php echo esc_attr($rent_selected); ?>">
                    <?php
                    if ($rent_selected != '') {
                        ?>
                        <option value="<?php echo esc_attr($rent_selected); ?>" hidden>
                            <?php
                            if ($rent_selected == 'Pay_By_Cash') {
                                echo esc_attr(__('Pay By Cash')); 
                            }elseif ($rent_selected == 'Pay_By_Cheque') {
                                echo esc_attr(__('Pay By Cheque')); 
                            }
                            ?>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Pay Rent By')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="Pay_By_Cash">Pay By Cash</option>
                    <option value="Pay_By_Cheque">Pay By Cheque</option>
                </select>
            </td>
        </tr>  

        <script type="text/javascript">
            jQuery(document).ready(function() {

                jQuery('[name="rent_selected"]').change(function() {
                    jQuery('[name="rent_selected"]').find('option').prop('disabled',false);

                    if (jQuery('[name="rent_selected"]').val() === "Pay_By_Cash") {
                        jQuery('<tr class="cash_tr"><td style="width: 200px">Enter Cash Amount</td><td><input type="number" name="rent_cash_amount" placeholder="Enter Cash Amount" value="<?php echo esc_attr($rent_cash_amount); ?>"></td></tr>').insertAfter('.select_tr');    
                        jQuery('.cheque_b_n').remove();
                        jQuery('.cheque_number').remove();
                        jQuery('.cheque_a_n').remove();
                        jQuery('.cheque_a_no').remove();

                    } else if (jQuery('[name="rent_selected"]').val() === "Pay_By_Cheque"){

                        jQuery('<tr class="cheque_b_n"><td style="width: 200px">Enter Bank Name</td><td><input type="text" name="rent_cheque_bank_name" placeholder="Enter Bank Name" value="<?php echo esc_attr($rent_cheque_bank_name); ?>"></td></tr>').insertAfter('.select_tr');

                        jQuery('<tr class="cheque_a_n"><td style="width: 200px">Enter Account Name</td><td><input type="text" name="rent_cheque_acc_name" id="rent_cheque_acc_name" placeholder="Enter Account Name" value="<?php echo esc_attr($rent_cheque_acc_name); ?>"></td></tr>').insertAfter('.cheque_b_n');

                        jQuery('<tr class="cheque_a_no"><td style="width: 200px">Enter Account Number</td><td><input type="text" name="rent_cheque_acc_no" id="rent_cheque_acc_no" placeholder="Enter Account Number" value="<?php echo esc_attr($rent_cheque_acc_no); ?>"></td></tr>').insertAfter('.cheque_a_n');

                        jQuery('<tr class="cheque_number"><td style="width: 200px">Enter Cheque Number</td><td><input type="number" name="rent_cheque_number" placeholder="Enter Cheque Number" value="<?php echo esc_attr($rent_cheque_number); ?>"></td></tr>').insertAfter('.cheque_a_no');


                        jQuery('.cash_tr').remove();
                    }
                });

                jQuery(window).load(function() {
                    if (jQuery('[name="rent_selected"]').val() === "Pay_By_Cash") {
                        jQuery('<tr class="cash_tr"><td style="width: 200px">Enter Cash Amount</td><td><input type="number" name="rent_cash_amount" placeholder="Enter Cash Amount" value="<?php echo esc_attr($rent_cash_amount); ?>"></td></tr>').insertAfter('.select_tr');    
                        jQuery('.cheque_b_n').remove();
                        jQuery('.cheque_number').remove();
                        jQuery('.cheque_a_n').remove();
                        jQuery('.cheque_a_no').remove();

                    } else if (jQuery('[name="rent_selected"]').val() === "Pay_By_Cheque"){

                        jQuery('<tr class="cheque_b_n"><td style="width: 200px">Enter Bank Name</td><td><input type="text" name="rent_cheque_bank_name" placeholder="Enter Bank Name" value="<?php echo esc_attr($rent_cheque_bank_name); ?>"></td></tr>').insertAfter('.select_tr');

                        jQuery('<tr class="cheque_a_n"><td style="width: 200px">Enter Account Name</td><td><input type="text" name="rent_cheque_acc_name" id="rent_cheque_acc_name" placeholder="Enter Account Name" value="<?php echo esc_attr($rent_cheque_acc_name); ?>"></td></tr>').insertAfter('.cheque_b_n');

                        jQuery('<tr class="cheque_a_no"><td style="width: 200px">Enter Account Number</td><td><input type="text" name="rent_cheque_acc_no" id="rent_cheque_acc_no" placeholder="Enter Account Number" value="<?php echo esc_attr($rent_cheque_acc_no); ?>"></td></tr>').insertAfter('.cheque_a_n');

                        jQuery('<tr class="cheque_number"><td style="width: 200px">Enter Cheque Number</td><td><input type="number" name="rent_cheque_number" placeholder="Enter Cheque Number" value="<?php echo esc_attr($rent_cheque_number); ?>"></td></tr>').insertAfter('.cheque_a_no');


                        jQuery('.cash_tr').remove();
                    }
                    var rent_by = jQuery('[name="rent_selected"]').val();      
                    if (rent_by === 'Pay_By_Cash' || rent_by === 'Pay_By_Cheque') {   
                        var val = jQuery('[name="rent_selected"] option:selected').val();
                        jQuery('[name="rent_selected"]').find('option[value='+val+']').prop('disabled',true);
                    }
                });


            });
        </script>  
    </table>
    <?php
}

function rent_pms_admin() {
    add_meta_box( 'rent_meta_box',
        'Pay Rent Details',
        'display_rent_meta_box',
        'rent', 'normal', 'high'
    );
}

add_action( 'admin_init', 'rent_pms_admin' );


function save_rent_fields( $rent_id, $rent ) {
    // Check post type for rent
    if ( $rent->post_type == 'rent' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['rent_cash_amount'] ) && $_POST['rent_cash_amount'] != '' ) {
            update_post_meta( $rent_id, 'rent_cash_amount', $_POST['rent_cash_amount'] );
        }
        if ( isset( $_POST['rent_cheque_bank_name'] ) && $_POST['rent_cheque_bank_name'] != '' ) {
            update_post_meta( $rent_id, 'rent_cheque_bank_name', $_POST['rent_cheque_bank_name'] );
        }
        if ( isset( $_POST['rent_cheque_number'] ) && $_POST['rent_cheque_number'] != '' ) {
            update_post_meta( $rent_id, 'rent_cheque_number', $_POST['rent_cheque_number'] );
        }
        if ( isset( $_POST['rent_cheque_acc_name'] ) && $_POST['rent_cheque_acc_name'] != '' ) {
            update_post_meta( $rent_id, 'rent_cheque_acc_name', $_POST['rent_cheque_acc_name'] );
        }
        if ( isset( $_POST['rent_cheque_acc_no'] ) && $_POST['rent_cheque_acc_no'] != '' ) {
            update_post_meta( $rent_id, 'rent_cheque_acc_no', $_POST['rent_cheque_acc_no'] );
        }
        if ( isset( $_POST['rent_selected'] ) && $_POST['rent_selected'] != '' ) {
            update_post_meta( $rent_id, 'rent_selected', $_POST['rent_selected'] );
        }

    }
}

add_action( 'save_post', 'save_rent_fields', 10, 2 );


