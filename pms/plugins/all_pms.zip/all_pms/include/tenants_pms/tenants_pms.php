<?php
/**
 * Custom tenants post
 */

function tenants_post_type (){
	
	$labels = array(
		'name' => 'Tenants',
		'singular_name' => 'tenants',
		'add_new' => 'Add New Tenants',
		'all_items' => 'All Tenants',
		'add_new_item' => 'Add Tenants',
		'edit_item' => 'Edit Tenants',
		'new_item' => 'New Tenants',
		'view_item' => 'View Tenants',
		'search_item' => 'Search Tenants',
		'not_found' => 'No Tenants found',
		'not_found_in_trash' => 'No Tenants found in trash',
		'parent_item_colon' => 'Parent Tenants'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' =>  'data:image/svg+xml;base64,' . base64_encode(
            file_get_contents( plugin_dir_url( __FILE__ ) . 'img/tenant.svg' )
        ),
		'supports' => array(
			'title',
			'thumbnail',
		),
		'menu_position' => 15,
		'exclude_from_search' => false
	);
	register_post_type('tenants',$args);
}
add_action('init','tenants_post_type');


function display_tenants_meta_box( $tenants ) {
    $tenants_property = esc_html( get_post_meta( $tenants->ID, 'tenants_property', true ) );
    $primary_tenants_name = esc_html( get_post_meta( $tenants->ID, 'primary_tenants_name', true ) );
    $primary_tenants_phone = esc_html( get_post_meta( $tenants->ID, 'primary_tenants_phone', true ) );
    $primary_tenants_email = esc_html( get_post_meta( $tenants->ID, 'primary_tenants_email', true ) );
    $secondary_tenants_name = esc_html( get_post_meta( $tenants->ID, 'secondary_tenants_name', true ) );
    $secondary_tenants_phone = esc_html( get_post_meta( $tenants->ID, 'secondary_tenants_phone', true ) );
    $secondary_tenants_email = esc_html( get_post_meta( $tenants->ID, 'secondary_tenants_email', true ) );
    $additional_tenants_name = esc_html( get_post_meta( $tenants->ID, 'additional_tenants_name', true ) );
    $lease_term_tenants = esc_html( get_post_meta( $tenants->ID, 'lease_term_tenants', true ) );
    $lease_term_end = esc_html( get_post_meta( $tenants->ID, 'lease_term_end', true ) );
    ?>
    <table>

        <tr>
            <td style="width: 200px">Assign Tenant To Property</td>
            <td><select name="tenants_property" value="<?php echo esc_attr($tenants_property); ?>">
                    <?php
                    if ($tenants_property != '') {
                    ?>
                    <option value="<?php echo esc_attr($tenants_property); ?>" hidden><?php echo esc_attr($tenants_property); ?></option>
                    <?php
                    }else{
                    ?>
                    <option value="" selected disabled hidden><?php echo esc_attr(__('Select Property')); ?></option> 
                    <?php
                    }
                        $search = new WP_Query( array(
                          'post_type' => 'property',
                        ));

                        if($search->have_posts()) { 
                          while($search->have_posts()) { $search->the_post(); 
                          ?>    
                          <option value="<?php the_title(); ?>"><?php the_title(); ?></option>
                        <?php }
                      }?>

                    ?>
                </select> 
            </td>
        </tr>
        <tr>
            <td style="width: 200px">Primary Tenant Name</td>
            <td><input type="text" size="80" name="primary_tenants_name" value="<?php echo esc_attr($primary_tenants_name); ?>"  required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Primary Tenant Email</td>
            <td><input type="email" size="80" name="primary_tenants_email" value="<?php echo esc_attr($primary_tenants_email); ?>" required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Primary Tenant Phone</td>
            <td><input type="number" class="number_width" size="80" name="primary_tenants_phone" value="<?php echo esc_attr($primary_tenants_phone); ?>" required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Secondary Tenant Name</td>
            <td><input type="text" size="80" name="secondary_tenants_name" value="<?php echo esc_attr($secondary_tenants_name); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Secondary Tenant Email</td>
            <td><input type="email" size="80" name="secondary_tenants_email" value="<?php echo esc_attr($secondary_tenants_email); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Secondary Tenant Phone</td>
            <td><input type="number" class="number_width" size="80" name="secondary_tenants_phone" value="<?php echo esc_attr($secondary_tenants_phone); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Additional Tenant Name(s)</td>
            <td><input type="text" size="80" name="secondary_tenants_name" value="<?php echo esc_attr($secondary_tenants_name); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 200px">Lease Term</td>
            <td><select name="lease_term_tenants" value="<?php echo esc_attr($lease_term_tenants); ?>">
                    <?php
                    if ($lease_term_tenants != '') {
                    ?>
                    <option value="<?php echo esc_attr($lease_term_tenants); ?>" hidden><?php echo esc_attr($lease_term_tenants); ?></option>
                    <?php
                    }else{
                    ?>
                    <option value="" selected disabled hidden><?php echo esc_attr(__('Select Lease term')); ?></option> 
                    <?php
                    }
                    ?>
                    <option value="11 Months"><?php echo esc_attr(__('11 Months')); ?></option>
                    <option value="22 Months"><?php echo esc_attr(__('22 Months')); ?></option>
                </select> 
            </td>
        </tr>
        <tr>
            <td style="width: 200px">Lease Term End</td>
            <td><input type="checkbox" name="lease_term_end" <?php if ($lease_term_end == 'yes') { echo "checked='checked'"; } ?>/>Yes</td>

        </tr>
    </table>
    <?php
}

function tenants_pms_admin() {
    add_meta_box( 'tenants_meta_box',
        'Tenants Details',
        'display_tenants_meta_box',
        'tenants', 'normal', 'high'
    );
}

add_action( 'admin_init', 'tenants_pms_admin' );


function save_tenants_fields( $tenants_id, $tenants ) {
    // Check post type for tenants
    if ( $tenants->post_type == 'tenants' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['tenants_property'] ) && $_POST['tenants_property'] != '' ) {
            update_post_meta( $tenants_id, 'tenants_property', $_POST['tenants_property'] );
        }
        if ( isset( $_POST['primary_tenants_name'] ) && $_POST['primary_tenants_name'] != '' ) {
            update_post_meta( $tenants_id, 'primary_tenants_name', $_POST['primary_tenants_name'] );
        }
        if ( isset( $_POST['primary_tenants_phone'] ) && $_POST['primary_tenants_phone'] != '' ) {
            update_post_meta( $tenants_id, 'primary_tenants_phone', $_POST['primary_tenants_phone'] );
        }
        if ( isset( $_POST['primary_tenants_email'] ) && $_POST['primary_tenants_email'] != '' ) {
            update_post_meta( $tenants_id, 'primary_tenants_email', $_POST['primary_tenants_email'] );
        }
        if ( isset( $_POST['secondary_tenants_name'] ) && $_POST['secondary_tenants_name'] != '' ) {
            update_post_meta( $tenants_id, 'secondary_tenants_name', $_POST['secondary_tenants_name'] );
        }
        if ( isset( $_POST['secondary_tenants_phone'] ) && $_POST['secondary_tenants_phone'] != '' ) {
            update_post_meta( $tenants_id, 'secondary_tenants_phone', $_POST['secondary_tenants_phone'] );
        }
        if ( isset( $_POST['additional_tenants_name'] ) && $_POST['additional_tenants_name'] != '' ) {
            update_post_meta( $tenants_id, 'additional_tenants_name', $_POST['additional_tenants_name'] );
        }
        if ( isset( $_POST['lease_term_tenants'] ) && $_POST['lease_term_tenants'] != '' ) {
            update_post_meta( $tenants_id, 'lease_term_tenants', $_POST['lease_term_tenants'] );
        }
        if ( isset( $_POST['secondary_tenants_email'] ) && $_POST['secondary_tenants_email'] != '' ) {
            update_post_meta( $tenants_id, 'secondary_tenants_email', $_POST['secondary_tenants_email'] );
        }
        if ( isset( $_POST['lease_term_end'] ) && $_POST['lease_term_end'] != '' ) {
            update_post_meta( $tenants_id, 'lease_term_end', 'yes' );
        }else{
            update_post_meta( $tenants_id, 'lease_term_end', 'no' );
        }
    }
}

add_action( 'save_post', 'save_tenants_fields', 10, 2 );




add_filter( 'post_row_actions', 'remove_row_actions', 10, 1 );
function remove_row_actions( $actions )
{
    if( get_post_type() === 'tenants' )
        unset( $actions['trash'] );
    return $actions;
}

add_action( 'admin_head', 'wpse_237305_disable_trash' );

function wpse_237305_disable_trash() {
    global $pagenow;

    if ( $pagenow == 'post.php' ) {
        if( get_post_type() === 'tenants' ){
        ?>
        <script type="text/javascript">
            jQuery( document ).ready( function( $ ) {
                jQuery( '#delete-action' ).remove();
            } );
        </script>
        <?php
    }
    }
}

add_action( 'admin_head', 'wp_trash_remove' );

function wp_trash_remove() {
    global $pagenow;

    if ( $pagenow == 'edit.php' ) {
        if( get_post_type() === 'tenants' ){
        ?>
        <script type="text/javascript">
            jQuery( document ).ready( function( $ ) {
                jQuery( '.actions.bulkactions option[value="trash"]' ).remove();
            } );
        </script>
        <?php
    }
    }
}

/*define('EMPTY_TRASH_DAYS', 0);*/



function my_delete_post_link($actions, $post)
{
    $lease_term_end = esc_html( get_post_meta( $post->ID, 'lease_term_end', true ) );
    if ($post->post_type == 'tenants'){
        if ($lease_term_end == 'yes') {
        $actions['delete'] = '<a href="' . wp_nonce_url( get_bloginfo('url') . '/wp-admin/post.php?action=delete&amp;post='. $post->ID, 'delete-post_' . $post->ID) . '">Delete</a>';
        }
    }
    return $actions;
}
add_filter('post_row_actions', 'my_delete_post_link', 10, 2);