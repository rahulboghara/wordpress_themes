<?php
/**
 * Custom Maintenance Requests For User
 */

function maintenance_user_post_type (){
	
	$labels = array(
		'name' => 'Maintenance Requests For User',
		'singular_name' => 'maintenance_user',
		'add_new' => 'Add New Maintenance Requests',
		'all_items' => 'All Maintenance Requests For User',
		'add_new_item' => 'Add Maintenance Requests',
		'edit_item' => 'Edit Maintenance Requests',
		'new_item' => 'New Maintenance Requests For User',
		'view_item' => 'View Maintenance Requests For User',
		'search_item' => 'Search Maintenance Requests For User',
		'not_found' => 'No Maintenance Requests For User found',
		'not_found_in_trash' => 'No Maintenance Requests For User found in trash',
		'parent_item_colon' => 'Parent Maintenance Requests For User'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => array('user_maintenance','user_maintenances','post'),
        'map_meta_cap' => true,
		'hierarchical' => false,
		'menu_icon' =>  'data:image/svg+xml;base64,' . base64_encode(
            file_get_contents( plugin_dir_url( __FILE__ ) . 'img/logo.svg' )
        ),
		'supports' => array(
			'title',
		),
        'menu_position' => 16,
        'exclude_from_search' => false
    );
	register_post_type('maintenance_user',$args);
}
add_action('init','maintenance_user_post_type');

add_action( 'init', 'user_maintenance_caps');

function user_maintenance_caps() {
    global $wp_roles;

    if ( isset($wp_roles) ) {
        $wp_roles->add_cap( 'tenants', 'edit_user_maintenance' );
        $wp_roles->add_cap( 'tenants', 'read_user_maintenance' );
        $wp_roles->add_cap( 'tenants', 'delete_user_maintenance' );
        $wp_roles->add_cap( 'tenants', 'publish_user_maintenances' );
        $wp_roles->add_cap( 'tenants', 'edit_user_maintenances' );
        $wp_roles->add_cap( 'tenants', 'edit_others_user_maintenances' );
        $wp_roles->add_cap( 'tenants', 'delete_user_maintenances' );
        $wp_roles->add_cap( 'tenants', 'delete_others_user_maintenances' );
        $wp_roles->add_cap( 'tenants', 'read_private_user_maintenances' );

        $wp_roles->add_cap( 'administrator', 'edit_user_maintenance' );
        $wp_roles->add_cap( 'administrator', 'read_user_maintenance' );
        $wp_roles->add_cap( 'administrator', 'delete_user_maintenance' );
        $wp_roles->add_cap( 'administrator', 'publish_user_maintenances' );
        $wp_roles->add_cap( 'administrator', 'edit_user_maintenances' );
        $wp_roles->add_cap( 'administrator', 'edit_others_user_maintenances' );
        $wp_roles->add_cap( 'administrator', 'delete_user_maintenances' );
        $wp_roles->add_cap( 'administrator', 'delete_others_user_maintenances' );
        $wp_roles->add_cap( 'administrator', 'read_private_user_maintenances' );

    }
}

function display_maintenance_user_meta_box( $maintenance_user ) {
    $maintenance_user_rq_name = esc_html( get_post_meta( $maintenance_user->ID, 'maintenance_user_rq_name', true ) );
    $maintenance_user_rq_desc = esc_html( get_post_meta( $maintenance_user->ID, 'maintenance_user_rq_desc', true ) );
    $maintenance_user_rq_urgency = esc_html( get_post_meta( $maintenance_user->ID, 'maintenance_user_rq_urgency', true ) );
    

    ?>
    <table>
        <tr>
            <td style="width: 200px">Request Name</td>
            <td><input type="text" size="80" name="maintenance_user_rq_name" placeholder="Enter Request Name" value="<?php echo esc_attr($maintenance_user_rq_name); ?>"  required/></td>
        </tr>
        <tr>
            <td style="width: 200px">Request Description</td>
            <td><textarea name="maintenance_user_rq_desc" placeholder="Enter Request Description"/><?php echo esc_attr($maintenance_user_rq_desc); ?></textarea></td>
        </tr>       
        <tr>
            <td style="width: 200px">Request Urgency</td>
            <td>
                <select name="maintenance_user_rq_urgency" value="<?php echo esc_attr($maintenance_user_rq_urgency); ?>">
                    <?php
                    if ($maintenance_user_rq_urgency != '') {
                        ?>
                        <option value="<?php echo esc_attr($maintenance_user_rq_urgency); ?>" hidden><?php echo esc_attr($maintenance_user_rq_urgency); ?></option>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Request Urgency')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="On-Time">On-Time</option>
                    <option value="Letter">Letter</option>

                </select>
            </td>
        </tr>  
    </table>
    <?php
}

function maintenance_user_pms_admin() {
    add_meta_box( 'maintenance_user_meta_box',
        'Maintenance Requests For User Details',
        'display_maintenance_user_meta_box',
        'maintenance_user', 'normal', 'high'
    );
}

add_action( 'admin_init', 'maintenance_user_pms_admin' );


function save_maintenance_user_fields( $maintenance_user_rq_id, $maintenance_user ) {
    // Check post type for maintenance_user
    if ( $maintenance_user->post_type == 'maintenance_user' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['maintenance_user_rq_name'] ) && $_POST['maintenance_user_rq_name'] != '' ) {
            update_post_meta( $maintenance_user_rq_id, 'maintenance_user_rq_name', $_POST['maintenance_user_rq_name'] );
        }
        if ( isset( $_POST['maintenance_user_rq_desc'] ) && $_POST['maintenance_user_rq_desc'] != '' ) {
            update_post_meta( $maintenance_user_rq_id, 'maintenance_user_rq_desc', $_POST['maintenance_user_rq_desc'] );
        }
        if ( isset( $_POST['maintenance_user_rq_urgency'] ) && $_POST['maintenance_user_rq_urgency'] != '' ) {
            update_post_meta( $maintenance_user_rq_id, 'maintenance_user_rq_urgency', $_POST['maintenance_user_rq_urgency'] );
        }


    }
}

add_action( 'save_post', 'save_maintenance_user_fields', 10, 2 );
