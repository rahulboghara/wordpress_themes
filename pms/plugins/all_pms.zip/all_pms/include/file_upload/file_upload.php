<?php

/**
 * Custom Documents Upload 
 */

function doc_upload_post_type (){
    
    $labels = array(
        'name' => 'Documents Upload',
        'singular_name' => 'doc_upload',
        'add_new' => 'Add New Documents Upload',
        'all_items' => 'All Documents Upload',
        'add_new_item' => 'Add Documents Upload',
        'edit_item' => 'Edit Documents Upload',
        'new_item' => 'New Documents Upload',
        'view_item' => 'View Documents Upload',
        'search_item' => 'Search Documents Upload',
        'not_found' => 'No Documents Upload found',
        'not_found_in_trash' => 'No Documents Upload found in trash',
        'padoc_upload_item_colon' => 'Parent Documents Upload'
    );
    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'publicly_queryable' => true,
        'query_var' => true,
        'rewrite' => true,
        'capability_type' => array('doc_upload','doc_uploads','post'),
        'map_meta_cap' => true,
        'hierarchical' => false,
        'menu_icon' => 'dashicons-upload',
        'supports' => array(
            'title',
        ),
        'menu_position' => 15,
        'exclude_from_search' => false
    );
    register_post_type('doc_upload',$args);
}
add_action('init','doc_upload_post_type');


add_action( 'init', 'doc_upload_caps');

function doc_upload_caps() {
    global $wp_roles;

    if ( isset($wp_roles) ) {
        $wp_roles->add_cap( 'tenants', 'edit_doc_upload' );
        $wp_roles->add_cap( 'tenants', 'read_doc_upload' );
        $wp_roles->add_cap( 'tenants', 'delete_doc_upload' );
        $wp_roles->add_cap( 'tenants', 'publish_doc_uploads' );
        $wp_roles->add_cap( 'tenants', 'edit_doc_uploads' );
        $wp_roles->add_cap( 'tenants', 'edit_others_doc_uploads' );
        $wp_roles->add_cap( 'tenants', 'delete_doc_uploads' );
        $wp_roles->add_cap( 'tenants', 'delete_others_doc_uploads' );
        $wp_roles->add_cap( 'tenants', 'read_private_doc_uploads' );

        $wp_roles->add_cap( 'administrator', 'edit_doc_upload' );
        $wp_roles->add_cap( 'administrator', 'read_doc_upload' );
        $wp_roles->add_cap( 'administrator', 'delete_doc_upload' );
        $wp_roles->add_cap( 'administrator', 'publish_doc_uploads' );
        $wp_roles->add_cap( 'administrator', 'edit_doc_uploads' );
        $wp_roles->add_cap( 'administrator', 'edit_others_doc_uploads' );
        $wp_roles->add_cap( 'administrator', 'delete_doc_uploads' );
        $wp_roles->add_cap( 'administrator', 'delete_others_doc_uploads' );
        $wp_roles->add_cap( 'administrator', 'read_private_doc_uploads' );

    }
}
    
/**
 * Add custom attachment metabox.
 */

function doc_upload_pms_admin() {
    add_meta_box( 'doc_upload_meta_box',
        'Documents Upload Details',
        'doc_upload_meta_box',
        'doc_upload', 'normal', 'high'
    );
}

add_action( 'admin_init', 'doc_upload_pms_admin' );


/**
 * Custom attachment metabox markup.
 */
if ( ! function_exists( 'download_url' ) ) {
    require_once ABSPATH . 'wp-admin/includes/file.php';
}

/**
 * Add functionality for file upload.
 */
function update_edit_form() {
    echo ' enctype="multipart/form-data"';
}
add_action( 'post_edit_form_tag', 'update_edit_form' );


function doc_upload_meta_box() {
    wp_nonce_field( plugin_basename(__FILE__), 'doc_upload_meta_box_nonce' );
    $html = '<p class="description">Upload your PDF or Document here.</p>';
    $html .= '<input id="doc_upload_meta_box" name="doc_upload_meta_box" size="25" type="file" value="" />';

    $filearray = get_post_meta( get_the_ID(), 'doc_upload_meta_box', true );
    $this_file = $filearray['url'];
    $path = str_replace( site_url('/'), ABSPATH, esc_url( $this_file) );
    $filename = basename($path); 


    if ( $this_file != '' ) { 

         $html .= '<div><p>Current file: ' . $filename . '</p></div>'; 
         $html .= '<a href="' . $this_file . '" target="_blank" class="button button-primary user_export_button" style="margin-right: 10px;">View File</a>'; 
         $html .= '<a href="' . $this_file . '" target="_blank" class="button button-primary user_export_button" style="margin-right: 10px;" download>Download File</a>'; 

    }
    echo $html; 
}

add_action( 'admin_footer', 'Check_size' );
function Check_size() {
?>
<script type="text/javascript">

jQuery("input[type='file']").on("change", function () {
     if(this.files[0].size > 5000000) {
       alert("Please upload file less than 5MB. Thanks!!");
       jQuery(this).val('');
     }
    });

</script>

<?php
}
/**
 * Save custom attachment metabox info.
 */
function save_doc_upload_fields( $id ) {
    if ( ! empty( $_FILES['doc_upload_meta_box']['name'] ) ) {
        $supported_types = array( 'application/ms-doc','application/doc','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/msword','application/pdf' );
        $arr_file_type = wp_check_filetype( basename( $_FILES['doc_upload_meta_box']['name'] ) );
        $uploaded_type = $arr_file_type['type'];

        if ( in_array( $uploaded_type, $supported_types ) ) {
            $upload = wp_upload_bits($_FILES['doc_upload_meta_box']['name'], null, file_get_contents($_FILES['doc_upload_meta_box']['tmp_name']));
            if ( isset( $upload['error'] ) && $upload['error'] != 0 ) {
                wp_die( 'There was an error uploading your file. The error is: ' . $upload['error'] );
            } else {
                add_post_meta( $id, 'doc_upload_meta_box', $upload );
                update_post_meta( $id, 'doc_upload_meta_box', $upload );
            }
        }
        else {
            wp_die( "The file type that you've uploaded is not a PDF or Document." );
        }
    }
}
add_action( 'save_post', 'save_doc_upload_fields' );



