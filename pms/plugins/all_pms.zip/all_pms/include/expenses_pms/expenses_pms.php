<?php

/**
 * Custom Property Expenses
 */

function expenses_post_type (){
	
	$labels = array(
		'name' => 'Property Expenses',
		'singular_name' => 'expenses',
		'add_new' => 'Add New Property Expenses',
		'all_items' => 'All Property Expenses',
		'add_new_item' => 'Add Property Expenses',
		'edit_item' => 'Edit Property Expenses',
		'new_item' => 'New Property Expenses',
		'view_item' => 'View Property Expenses',
		'search_item' => 'Search Property Expenses',
		'not_found' => 'No Property Expenses found',
		'not_found_in_trash' => 'No Property Expenses found in trash',
		'parent_item_colon' => 'Parent Property Expenses'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' =>  'data:image/svg+xml;base64,' . base64_encode(
            file_get_contents( plugin_dir_url( __FILE__ ) . 'img/rich.svg' )
        ),
		'supports' => array(
			'title',
		),
        'menu_position' => 15,
        'exclude_from_search' => false
    );
	register_post_type('expenses',$args);
}
add_action('init','expenses_post_type');



function display_expenses_meta_box( $expenses ) {
    $maintenance_name = esc_html( get_post_meta( $expenses->ID, 'maintenance_name', true ) );
    $maintenance_desc = esc_html( get_post_meta( $expenses->ID, 'maintenance_desc', true ) );
    $maintenance_amount = esc_html( get_post_meta( $expenses->ID, 'maintenance_amount', true ) );

    $recurring_name = esc_html( get_post_meta( $expenses->ID, 'recurring_name', true ) );
    $recurring_desc = esc_html( get_post_meta( $expenses->ID, 'recurring_desc', true ) );
    $recurring_amount = esc_html( get_post_meta( $expenses->ID, 'recurring_amount', true ) );
    $recu_occu_freq = esc_html( get_post_meta( $expenses->ID, 'recu_occu_freq', true ) );

    $recurring_fee_name = esc_html( get_post_meta( $expenses->ID, 'recurring_fee_name', true ) );
    $recurring_fee_desc = esc_html( get_post_meta( $expenses->ID, 'recurring_fee_desc', true ) );
    $recurring_fee_amount = esc_html( get_post_meta( $expenses->ID, 'recurring_fee_amount', true ) );
    $recu_fee_occu_freq = esc_html( get_post_meta( $expenses->ID, 'recu_fee_occu_freq', true ) );

    $expenses_selected = esc_html( get_post_meta( $expenses->ID, 'expenses_selected', true ) );
    

    ?>
    <table>
        <tr class="expenses_tr">
            <td style="width: 200px">Select Property Expenses</td>
            <td>
                <select name="expenses_selected" value="<?php echo esc_attr($expenses_selected); ?>">
                    <?php
                    if ($expenses_selected != '') {
                        ?>
                        <option value="<?php echo esc_attr($expenses_selected); ?>" hidden>
                            <?php
                            if ($expenses_selected == 'one_time_maintenance') {
                                echo esc_attr(__('One-Time Maintenance Fee')); 
                            }elseif ($expenses_selected == 'recurring_expenses') {
                                echo esc_attr(__('Recurring Expenses')); 
                            }elseif ($expenses_selected == 'recurring_fees') {
                                echo esc_attr(__('Recurring Fees')); 
                            }
                            ?>
                        </option>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Property Expenses')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="one_time_maintenance">One-Time Maintenance Fee</option>
                    <option value="recurring_expenses">Recurring Expenses</option>
                    <option value="recurring_fees">Recurring Fees</option>

                </select>
            </td>
        </tr>  

        <script type="text/javascript">
            jQuery(document).ready(function() {

                jQuery('[name="expenses_selected"]').change(function() {
                    jQuery('[name="expenses_selected"]').find('option').prop('disabled',false);

                    if (jQuery('[name="expenses_selected"]').val() === "one_time_maintenance") {
                        jQuery('<tr class="main_name_tr"><td style="width: 200px">Maintenance name</td><td><input type="text" name="maintenance_name" placeholder="Enter Maintenance name" value="<?php echo esc_attr($maintenance_name); ?>"></td></tr>').insertAfter('.expenses_tr');   
                        jQuery('<tr class="main_desc_tr"><td style="width: 200px">Maintenance Description</td><td><textarea type="text" name="maintenance_desc" placeholder="Enter Maintenance Description"><?php echo esc_attr($maintenance_desc); ?></textarea></td></tr>').insertAfter('.main_name_tr');
                        jQuery('<tr class="main_amount_tr"><td style="width: 200px">Maintenance amount</td><td><input type="number" name="maintenance_amount" placeholder="Enter Maintenance amount" value="<?php echo esc_attr($maintenance_amount); ?>"></td></tr>').insertAfter('.main_desc_tr');

                        jQuery('.recu_name_tr').remove();
                        jQuery('.recu_desc_tr').remove();
                        jQuery('.recu_amount_tr').remove();
                        jQuery('.recu_occu_tr').remove();
                        jQuery('.recu_fee_name_tr').remove();
                        jQuery('.recu_fee_desc_tr').remove();
                        jQuery('.recu_fee_amount_tr').remove();
                        jQuery('.recu_fee_occu_tr').remove();

                    } else if (jQuery('[name="expenses_selected"]').val() === "recurring_expenses"){

                        jQuery('<tr class="recu_name_tr"><td style="width: 200px">Expense name</td><td><input type="text" name="recurring_name" placeholder="Enter Expense name" value="<?php echo esc_attr($recurring_name); ?>"></td></tr>').insertAfter('.expenses_tr');   
                        jQuery('<tr class="recu_desc_tr"><td style="width: 200px">Expense Description</td><td><textarea type="text" name="recurring_desc" placeholder="Enter Expense Description"><?php echo esc_attr($recurring_desc); ?></textarea></td></tr>').insertAfter('.recu_name_tr');
                        jQuery('<tr class="recu_amount_tr"><td style="width: 200px">Expense amount</td><td><input type="number" name="recurring_amount" placeholder="Enter Expense amount" value="<?php echo esc_attr($recurring_amount); ?>"></td></tr>').insertAfter('.recu_desc_tr');

                         jQuery('<tr class="recu_occu_tr"><td style="width: 200px">Enter Occurrence Frequency</td><td><select  name="recu_occu_freq" value="<?php echo esc_attr($recu_occu_freq); ?>"><?php if ($recu_occu_freq != ''): ?><option value="<?php echo esc_attr($recu_occu_freq); ?>" hidden><?php echo esc_attr($recu_occu_freq); ?></option><?php else: ?><option value="" selected disabled hidden><?php echo esc_attr(__('Select Occurrence Frequency')); ?></option><?php endif ?></select></td></tr>').insertAfter('.recu_amount_tr');

                        jQuery(function(){
                            var $select = jQuery('[name="recu_occu_freq"]');
                            for (i=0;i<=12;i++){
                                $select.append(jQuery('<option></option>').val(i).html(i));
                            }
                        }); 

                        jQuery('.main_name_tr').remove();
                        jQuery('.main_desc_tr').remove();
                        jQuery('.main_amount_tr').remove();
                        jQuery('.recu_fee_name_tr').remove();
                        jQuery('.recu_fee_desc_tr').remove();
                        jQuery('.recu_fee_amount_tr').remove();
                        jQuery('.recu_fee_occu_tr').remove();


                    }else if (jQuery('[name="expenses_selected"]').val() === "recurring_fees"){

                        jQuery('<tr class="recu_fee_name_tr"><td style="width: 200px">Fee name</td><td><input type="text" name="recurring_fee_name" placeholder="Enter Fee name" value="<?php echo esc_attr($recurring_fee_name); ?>"></td></tr>').insertAfter('.expenses_tr');   
                        jQuery('<tr class="recu_fee_desc_tr"><td style="width: 200px">Fee Description</td><td><textarea type="text" name="recurring_fee_desc" placeholder="Enter Fee Description"><?php echo esc_attr($recurring_fee_desc); ?></textarea></td></tr>').insertAfter('.recu_fee_name_tr');
                        jQuery('<tr class="recu_fee_amount_tr"><td style="width: 200px">Fee amount</td><td><input type="number" name="recurring_fee_amount" placeholder="Enter Fee amount" value="<?php echo esc_attr($recurring_fee_amount); ?>"></td></tr>').insertAfter('.recu_fee_desc_tr');

                         jQuery('<tr class="recu_fee_occu_tr"><td style="width: 200px">Fee Occurrence Frequency</td><td><select  name="recu_fee_occu_freq" value="<?php echo esc_attr($recu_fee_occu_freq); ?>"><?php if ($recu_fee_occu_freq != ''): ?><option value="<?php echo esc_attr($recu_fee_occu_freq); ?>" hidden><?php echo esc_attr($recu_fee_occu_freq); ?></option><?php else: ?><option value="" selected disabled hidden><?php echo esc_attr(__('Select Fee Occurrence Frequency')); ?></option><?php endif ?></select></td></tr>').insertAfter('.recu_fee_amount_tr');

                        jQuery(function(){
                            var $select = jQuery('[name="recu_fee_occu_freq"]');
                            for (i=0;i<=12;i++){
                                $select.append(jQuery('<option></option>').val(i).html(i));
                            }
                        }); 

                        jQuery('.main_name_tr').remove();
                        jQuery('.main_desc_tr').remove();
                        jQuery('.main_amount_tr').remove();
                        jQuery('.recu_name_tr').remove();
                        jQuery('.recu_desc_tr').remove();
                        jQuery('.recu_amount_tr').remove();
                        jQuery('.recu_occu_tr').remove();
                    }
                });

                jQuery(window).load(function() {
                    if (jQuery('[name="expenses_selected"]').val() === "one_time_maintenance") {
                        jQuery('<tr class="main_name_tr"><td style="width: 200px">Maintenance name</td><td><input type="text" name="maintenance_name" placeholder="Enter Maintenance name" value="<?php echo esc_attr($maintenance_name); ?>"></td></tr>').insertAfter('.expenses_tr');   
                        jQuery('<tr class="main_desc_tr"><td style="width: 200px">Maintenance Description</td><td><textarea type="text" name="maintenance_desc" placeholder="Enter Maintenance Description"><?php echo esc_attr($maintenance_desc); ?></textarea></td></tr>').insertAfter('.main_name_tr');
                        jQuery('<tr class="main_amount_tr"><td style="width: 200px">Maintenance amount</td><td><input type="number" name="maintenance_amount" placeholder="Enter Maintenance amount" value="<?php echo esc_attr($maintenance_amount); ?>"></td></tr>').insertAfter('.main_desc_tr');

                        jQuery('.recu_name_tr').remove();
                        jQuery('.recu_desc_tr').remove();
                        jQuery('.recu_amount_tr').remove();
                        jQuery('.recu_occu_tr').remove();
                        jQuery('.recu_fee_name_tr').remove();
                        jQuery('.recu_fee_desc_tr').remove();
                        jQuery('.recu_fee_amount_tr').remove();
                        jQuery('.recu_fee_occu_tr').remove();

                    } else if (jQuery('[name="expenses_selected"]').val() === "recurring_expenses"){

                        jQuery('<tr class="recu_name_tr"><td style="width: 200px">Expense name</td><td><input type="text" name="recurring_name" placeholder="Enter Expense name" value="<?php echo esc_attr($recurring_name); ?>"></td></tr>').insertAfter('.expenses_tr');   
                        jQuery('<tr class="recu_desc_tr"><td style="width: 200px">Expense Description</td><td><textarea type="text" name="recurring_desc" placeholder="Enter Expense Description"><?php echo esc_attr($recurring_desc); ?></textarea></td></tr>').insertAfter('.recu_name_tr');
                        jQuery('<tr class="recu_amount_tr"><td style="width: 200px">Expense amount</td><td><input type="number" name="recurring_amount" placeholder="Enter Expense amount" value="<?php echo esc_attr($recurring_amount); ?>"></td></tr>').insertAfter('.recu_desc_tr');
                        jQuery('<tr class="recu_occu_tr"><td style="width: 200px">Enter Occurrence Frequency</td><td><select  name="recu_occu_freq" value="<?php echo esc_attr($recu_occu_freq); ?>"><?php if ($recu_occu_freq != ''): ?><option value="<?php echo esc_attr($recu_occu_freq); ?>" hidden><?php echo esc_attr($recu_occu_freq); ?></option><?php else: ?><option value="" selected disabled hidden><?php echo esc_attr(__('Select Occurrence Frequency')); ?></option><?php endif ?></select></td></tr>').insertAfter('.recu_amount_tr');

                        jQuery(function(){
                            var $select = jQuery('[name="recu_occu_freq"]');
                            for (i=0;i<=12;i++){
                                $select.append(jQuery('<option></option>').val(i).html(i));
                            }
                        }); 

                        jQuery('.main_name_tr').remove();
                        jQuery('.main_desc_tr').remove();
                        jQuery('.main_amount_tr').remove();
                        jQuery('.recu_fee_name_tr').remove();
                        jQuery('.recu_fee_desc_tr').remove();
                        jQuery('.recu_fee_amount_tr').remove();
                        jQuery('.recu_fee_occu_tr').remove();


                    }else if (jQuery('[name="expenses_selected"]').val() === "recurring_fees"){

                        jQuery('<tr class="recu_fee_name_tr"><td style="width: 200px">Fee name</td><td><input type="text" name="recurring_fee_name" placeholder="Enter Fee name" value="<?php echo esc_attr($recurring_fee_name); ?>"></td></tr>').insertAfter('.expenses_tr');   
                        jQuery('<tr class="recu_fee_desc_tr"><td style="width: 200px">Fee Description</td><td><textarea type="text" name="recurring_fee_desc" placeholder="Enter Fee Description"><?php echo esc_attr($recurring_fee_desc); ?></textarea></td></tr>').insertAfter('.recu_fee_name_tr');
                        jQuery('<tr class="recu_fee_amount_tr"><td style="width: 200px">Fee amount</td><td><input type="number" name="recurring_fee_amount" placeholder="Enter Fee amount" value="<?php echo esc_attr($recurring_fee_amount); ?>"></td></tr>').insertAfter('.recu_fee_desc_tr');
                        jQuery('<tr class="recu_fee_occu_tr"><td style="width: 200px">Fee Occurrence Frequency</td><td><select  name="recu_fee_occu_freq" value="<?php echo esc_attr($recu_fee_occu_freq); ?>"><?php if ($recu_fee_occu_freq != ''): ?><option value="<?php echo esc_attr($recu_fee_occu_freq); ?>" hidden><?php echo esc_attr($recu_fee_occu_freq); ?></option><?php else: ?><option value="" selected disabled hidden><?php echo esc_attr(__('Select Fee Occurrence Frequency')); ?></option><?php endif ?></select></td></tr>').insertAfter('.recu_fee_amount_tr');

                        jQuery(function(){
                            var $select = jQuery('[name="recu_fee_occu_freq"]');
                            for (i=0;i<=12;i++){
                                $select.append(jQuery('<option></option>').val(i).html(i));
                            }
                        }); 

                        jQuery('.main_name_tr').remove();
                        jQuery('.main_desc_tr').remove();
                        jQuery('.main_amount_tr').remove();
                        jQuery('.recu_name_tr').remove();
                        jQuery('.recu_desc_tr').remove();
                        jQuery('.recu_amount_tr').remove();
                        jQuery('.recu_occu_tr').remove();
                    }
                    var expenses_by = jQuery('[name="expenses_selected"]').val();      
                    if (expenses_by === 'one_time_maintenance' || expenses_by === 'recurring_expenses' || expenses_by === 'recurring_fees') {   
                        var val = jQuery('[name="expenses_selected"] option:selected').val();
                        jQuery('[name="expenses_selected"]').find('option[value='+val+']').prop('disabled',true);
                    }
                });


            });
        </script>  
    </table>
    <?php
}

function expenses_pms_admin() {
    add_meta_box( 'expenses_meta_box',
        'Expenses Details',
        'display_expenses_meta_box',
        'expenses', 'normal', 'high'
    );
}

add_action( 'admin_init', 'expenses_pms_admin' );


function save_expenses_fields( $expenses_id, $expenses ) {
    // Check post type for expenses
    if ( $expenses->post_type == 'expenses' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['maintenance_name'] ) && $_POST['maintenance_name'] != '' ) {
            update_post_meta( $expenses_id, 'maintenance_name', $_POST['maintenance_name'] );
        }
        if ( isset( $_POST['maintenance_desc'] ) && $_POST['maintenance_desc'] != '' ) {
            update_post_meta( $expenses_id, 'maintenance_desc', $_POST['maintenance_desc'] );
        }
        if ( isset( $_POST['maintenance_amount'] ) && $_POST['maintenance_amount'] != '' ) {
            update_post_meta( $expenses_id, 'maintenance_amount', $_POST['maintenance_amount'] );
        }

        if ( isset( $_POST['recurring_name'] ) && $_POST['recurring_name'] != '' ) {
            update_post_meta( $expenses_id, 'recurring_name', $_POST['recurring_name'] );
        }
        if ( isset( $_POST['recurring_desc'] ) && $_POST['recurring_desc'] != '' ) {
            update_post_meta( $expenses_id, 'recurring_desc', $_POST['recurring_desc'] );
        }
        if ( isset( $_POST['recurring_amount'] ) && $_POST['recurring_amount'] != '' ) {
            update_post_meta( $expenses_id, 'recurring_amount', $_POST['recurring_amount'] );
        }

        if ( isset( $_POST['expenses_selected'] ) && $_POST['expenses_selected'] != '' ) {
            update_post_meta( $expenses_id, 'expenses_selected', $_POST['expenses_selected'] );
        }
        if ( isset( $_POST['recu_occu_freq'] ) && $_POST['recu_occu_freq'] != '' ) {
            update_post_meta( $expenses_id, 'recu_occu_freq', $_POST['recu_occu_freq'] );
        }

    }
}

add_action( 'save_post', 'save_expenses_fields', 10, 2 );


