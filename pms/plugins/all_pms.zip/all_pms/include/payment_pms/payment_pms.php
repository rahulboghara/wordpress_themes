<?php

/**
 * Custom payment post
 */

function payment_post_type (){
	
	$labels = array(
		'name' => 'Receive Payment',
		'singular_name' => 'payment',
		'add_new' => 'Add New Receive Payment',
		'all_items' => 'All Receive Payment',
		'add_new_item' => 'Add Receive Payment',
		'edit_item' => 'Edit Receive Payment',
		'new_item' => 'New Receive Payment',
		'view_item' => 'View Receive Payment',
		'search_item' => 'Search Receive Payment',
		'not_found' => 'No Receive Payment found',
		'not_found_in_trash' => 'No Receive Payment found in trash',
		'parent_item_colon' => 'Parent Receive Payment'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-money',
		'supports' => array(
			'title',
		),
        'menu_position' => 15,
        'exclude_from_search' => false
    );
	register_post_type('payment',$args);
}
add_action('init','payment_post_type');



function display_payment_meta_box( $payment ) {
    $payment_cash_amount = esc_html( get_post_meta( $payment->ID, 'payment_cash_amount', true ) );
    $payment_cheque_amount = esc_html( get_post_meta( $payment->ID, 'payment_cheque_amount', true ) );
    $payment_cheque_number = esc_html( get_post_meta( $payment->ID, 'payment_cheque_number', true ) );
    $payment_cheque_date = esc_html( get_post_meta( $payment->ID, 'payment_cheque_date', true ) );
    $payment_selected = esc_html( get_post_meta( $payment->ID, 'payment_selected', true ) );
    ?>
    <table>
        <tr class="select_tr">
            <td style="width: 200px">Manual Receive Payment</td>
            <td>
                <select name="payment_selected" class="form-control form-control-user" value="<?php echo esc_attr($payment_selected); ?>">
                    <?php
                    if ($payment_selected != '') {
                        ?>
                        <option value="<?php echo esc_attr($payment_selected); ?>" hidden>
                            <?php
                            if ($payment_selected == 'Payment_By_Cash') {
                                echo esc_attr(__('Payment By Cash')); 
                            }elseif ($payment_selected == 'Payment_By_Cheque') {
                                echo esc_attr(__('Payment By Cheque')); 
                            }
                            ?>
                        <?php
                    }else{
                        ?>
                        <option value="" selected disabled hidden><?php echo esc_attr(__('Select Receive Payment By')); ?></option> 
                        <?php
                    }
                    ?>
                    <option value="Payment_By_Cash">Payment By Cash</option>
                    <option value="Payment_By_Cheque">Payment By Cheque</option>
                </select>
            </td>
        </tr>  

        <script type="text/javascript">
            jQuery(document).ready(function() {

                jQuery('[name="payment_selected"]').change(function() {
                    jQuery('[name="payment_selected"]').find('option').prop('disabled',false);

                    if (jQuery('[name="payment_selected"]').val() === "Payment_By_Cash") {
                        jQuery('<tr class="cash_tr"><td style="width: 200px">Enter Cash Amount</td><td><input type="number" name="payment_cash_amount" placeholder="Enter Cash Amount" value="<?php echo esc_attr($payment_cash_amount); ?>"></td></tr>').insertAfter('.select_tr');    
                        jQuery('.cheque_amount').remove();
                        jQuery('.cheque_number').remove();
                        jQuery('.cheque_date').remove();
                    } else if (jQuery('[name="payment_selected"]').val() === "Payment_By_Cheque"){

                        jQuery('<tr class="cheque_amount"><td style="width: 200px">Enter Cheque Amount</td><td><input type="number" name="payment_cheque_amount" placeholder="Enter Cheque Amount" value="<?php echo esc_attr($payment_cheque_amount); ?>"></td></tr>').insertAfter('.select_tr');

                        jQuery('<tr class="cheque_number"><td style="width: 200px">Enter Cheque Number</td><td><input type="number" name="payment_cheque_number" placeholder="Enter Cheque Number" value="<?php echo esc_attr($payment_cheque_number); ?>"></td></tr>').insertAfter('.cheque_amount');

                        jQuery('<tr class="cheque_date"><td style="width: 200px">Enter Received Date</td><td><input type="text" name="payment_cheque_date" id="payment_cheque_date" placeholder="Enter Received Date" value="<?php echo esc_attr($payment_cheque_date); ?>"></td></tr>').insertAfter('.cheque_number');
                        jQuery('.cash_tr').remove();

                        jQuery('#payment_cheque_date').datepicker({
                        dateFormat : 'dd-mm-yy'
                        });
                    }
                });

                jQuery(window).load(function() {
                    if (jQuery('[name="payment_selected"]').val() === "Payment_By_Cash") {
                        jQuery('<tr class="cash_tr"><td style="width: 200px">Payment Amount Cash</td><td><input type="number" name="payment_cash_amount" placeholder="Enter Cash Amount" value="<?php echo esc_attr($payment_cash_amount); ?>"></td></tr>').insertAfter('.select_tr');
                        jQuery('.cheque_amount').remove();
                        jQuery('.cheque_number').remove();
                        jQuery('.cheque_date').remove();

                    } else if (jQuery('[name="payment_selected"]').val() === "Payment_By_Cheque") {
                        jQuery('<tr class="cheque_amount"><td style="width: 200px">Enter Cheque Amount</td><td><input type="number" name="payment_cheque_amount" placeholder="Enter Cheque Amount" value="<?php echo esc_attr($payment_cheque_amount); ?>"></td></tr>').insertAfter('.select_tr');

                        jQuery('<tr class="cheque_number"><td style="width: 200px">Enter Cheque Number</td><td><input type="number" name="payment_cheque_number" placeholder="Enter Cheque Number" value="<?php echo esc_attr($payment_cheque_number); ?>"></td></tr>').insertAfter('.cheque_amount');

                        jQuery('<tr class="cheque_date"><td style="width: 200px">Enter Received Date</td><td><input type="text" name="payment_cheque_date" id="payment_cheque_date" placeholder="Enter Received Date" value="<?php echo esc_attr($payment_cheque_date); ?>"></td></tr>').insertAfter('.cheque_number');
                        jQuery('.cash_tr').remove();

                        jQuery('#payment_cheque_date').datepicker({
                        dateFormat : 'dd-mm-yy'
                        });
                    }
                    var payment_by = jQuery('[name="payment_selected"]').val();      
                    if (payment_by === 'Payment_By_Cash' || payment_by === 'Payment_By_Cheque') {   
                        var val = jQuery('[name="payment_selected"] option:selected').val();
                        jQuery('[name="payment_selected"]').find('option[value='+val+']').prop('disabled',true);
                    }
                });


            });
        </script>  
    </table>
    <?php
}

function payment_pms_admin() {
    add_meta_box( 'payment_meta_box',
        'Payment Details',
        'display_payment_meta_box',
        'payment', 'normal', 'high'
    );
}

add_action( 'admin_init', 'payment_pms_admin' );


function save_payment_fields( $payment_id, $payment ) {
    // Check post type for payment
    if ( $payment->post_type == 'payment' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['payment_cash_amount'] ) && $_POST['payment_cash_amount'] != '' ) {
            update_post_meta( $payment_id, 'payment_cash_amount', $_POST['payment_cash_amount'] );
        }
        if ( isset( $_POST['payment_cheque_amount'] ) && $_POST['payment_cheque_amount'] != '' ) {
            update_post_meta( $payment_id, 'payment_cheque_amount', $_POST['payment_cheque_amount'] );
        }
        if ( isset( $_POST['payment_cheque_number'] ) && $_POST['payment_cheque_number'] != '' ) {
            update_post_meta( $payment_id, 'payment_cheque_number', $_POST['payment_cheque_number'] );
        }
        if ( isset( $_POST['payment_cheque_date'] ) && $_POST['payment_cheque_date'] != '' ) {
            update_post_meta( $payment_id, 'payment_cheque_date', $_POST['payment_cheque_date'] );
        }
        if ( isset( $_POST['payment_selected'] ) && $_POST['payment_selected'] != '' ) {
            update_post_meta( $payment_id, 'payment_selected', $_POST['payment_selected'] );
        }

    }
}

add_action( 'save_post', 'save_payment_fields', 10, 2 );


