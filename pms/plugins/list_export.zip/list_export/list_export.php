<?php
/*
Plugin Name: List Export
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a displaying List Export.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/




if ( ! defined( 'ABSPATH' ) ) die( 'Accessing this file directly is denied.' );

if (!class_exists('list_export')){
    class list_export{

        public function __construct()
        {   
            add_action('admin_menu', array($this, 'property_page_admin_page'));
        }

        function property_page_admin_page(){

        add_menu_page('List Export', 'List Export', 'manage_options','property-list-export','include_message_admin','dashicons-download', 22);   

        add_submenu_page(
            'property-list-export',       // parent slug
            'List Export',    // page title
            'List Export',             // menu title
            'manage_options',           // capability
            'property-list-export', // slug
            array(&$this, 'property_page_callback') // callback
        ); 

        }

        public function property_page_callback() {
            include plugin_dir_path( __FILE__ ) .'includes/export_list.php';
        }
    }
}
new list_export();






