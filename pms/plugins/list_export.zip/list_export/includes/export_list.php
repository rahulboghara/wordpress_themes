<?php
$abs_path= __FILE__;
$get_path=explode('wp-content',$abs_path);
$path=$get_path[0].'wp-load.php';
include($path);

?>
<style type="text/css">
    .table-bordered {
      border:1px solid black
  }
  td{
      border:1px solid black
  }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.3/jspdf.debug.js"></script>
<script type="text/javascript" src="<?php echo plugins_url( '', __FILE__ ); ?>/js/jspdf.min.js"></script>
<script type="text/javascript" src="<?php echo plugins_url( '', __FILE__ ); ?>/js/jspdf.plugin.autotable.js"></script>
<script type="text/javascript">

    function property_table() {
        var doc = new jsPDF();

        doc.setFontSize(18);
        doc.text('Property List', 14, 14);
        doc.setFontSize(11);
        doc.setTextColor(100);

        doc.autoTable({
            html: '#property_table',
            startY:20, 
            showHead: 'firstPage'
        });
        
        doc.save('property_export_list.pdf');
    }
    function tenants_table() {
        var doc = new jsPDF();

        doc.setFontSize(18);
        doc.text('Tenants List', 14, 14);
        doc.setFontSize(11);
        doc.setTextColor(100);

        doc.autoTable({
            html: '#tenants_table',
            startY:20, 
            showHead: 'firstPage'
        });
        
        doc.save('property_tenants_list.pdf');
    }
</script>
<div class="wrap">
<section>
  <h1>
    Export Property & Tenants List<br><br>
</h1>
</section>
<section>
  <ul>
    <li>
        <h2>Export Property List</h2>
      <a href="#" onClick="javascript:property_table();">
          <button class="button button-primary user_export_button" style="margin-bottom: 15px;">Export Property List</button>
      </a>
  </li>
  <li>
    <h2>Export Tenants List</h2>
      <a href="#" onClick="javascript:tenants_table();">
          <button class="button button-primary user_export_button" style="margin-bottom: 15px;">Export Tenants List</button>
      </a>
  </li>
</ul>
</section>
<div id="customers" style="display: none;">
    <div class="table-responsive">
        <table id="property_table"  class="table table-hover">
            <thead>
                <tr>
                    <th>Sr.No</th>
                    <th>Property Name</th>
                    <th>Property Address</th>
                    <th>Property Owner</th>
                    <th>Owner Address</th>
                    <th>Owner Phone</th>
                    <th>Owner Email</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sr_no = 1;
                $property_table = new WP_Query( array(
                  'post_type' => 'property',
              ));

                while($property_table->have_posts()) { $property_table->the_post();
                    $property_title = get_the_title();
                    $property_address = esc_html( get_post_meta( get_the_ID(), 'property_address', true ) ); 
                    $property_owner = esc_html( get_post_meta( get_the_ID(), 'property_owner', true ) );
                    $property_owner_address = esc_html( get_post_meta( get_the_ID(), 'property_owner_address', true ) );
                    $property_owner_phone = esc_html( get_post_meta( get_the_ID(), 'property_owner_phone', true ) );
                    $property_owner_email = esc_html( get_post_meta( get_the_ID(), 'property_owner_email', true ) );
                    echo "<tr>
                    <td>".$sr_no."</td>
                    <td>".$property_title."</td>
                    <td>".$property_address."</td>
                    <td>".$property_owner."</td>
                    <td>".$property_owner_address."</td>
                    <td>".$property_owner_phone."</td>
                    <td>".$property_owner_email."</td>
                    </tr>";
                    $sr_no++;
                }
                ?>
            </tbody>
        </table>
        <table id="tenants_table">
           <thead>
            <tr>
                <th>Sr.No</th>
                <th>Tenant Name</th>
                <th>Tenant Phone No.</th>
                <th>Tenant Email</th>
                <th>Property Tenant Assigned To</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sr_no = 1;
            $tenants_table = new WP_Query( array(
              'post_type' => 'tenants',
          ));

            while($tenants_table->have_posts()) { $tenants_table->the_post();

                    $tenants_title = get_the_title();
                    $tenants_property = esc_html( get_post_meta( get_the_ID(), 'tenants_property', true ) );
                    $primary_tenants_phone = esc_html( get_post_meta( get_the_ID(), 'primary_tenants_phone', true ) );
                    $primary_tenants_email = esc_html( get_post_meta( get_the_ID(), 'primary_tenants_email', true ) );
                    echo "<tr>
                    <td>".$sr_no."</td>
                    <td>".$tenants_title."</td>
                    <td>".$primary_tenants_phone."</td>
                    <td>".$primary_tenants_email."</td>
                    <td>".$tenants_property."</td>
                    </tr>";
                    $sr_no++;
                }
                ?>
        </tbody>
    </table>
</div>
</div>
</div>


<?php


