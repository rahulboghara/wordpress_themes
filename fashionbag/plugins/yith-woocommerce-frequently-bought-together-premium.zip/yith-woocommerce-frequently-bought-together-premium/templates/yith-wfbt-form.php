<?php
/**
 * Form template
 *
 * @author YITH
 * @package YITH WooCommerce Frequently Bought Together Premium
 * @version 1.3.0
 */

if( empty( $product ) ) {
    global $product;
}

if( ! isset( $products ) ) {
	return;
}
/**
 * @type $product WC_Product
 */
// set query
$url        = ! is_null( $product ) ? $product->get_permalink() : '';
$url        = add_query_arg( 'action', 'yith_bought_together', $url );
$url        = wp_nonce_url( $url, 'yith_bought_together' );
$is_wc_30   = version_compare( WC()->version, '3.0.0', '>=' );

?>

<div class="yith-wfbt-section woocommerce">
	<?php if( $title != '' ) {
		echo '<h3>' . esc_html( $title ) . '</h3>';
	}

    if( ! empty( $additional_text ) ){
        echo $additional_text;
    }

    ?>

    <form class="yith-wfbt-form" method="post" action="<?php echo esc_url( $url ) ?>">
      <ul class="yith-wfbt-items products columns-4">
        <div class="row">
            <?php $j = 0; foreach( $products as $product ) :
            $product_id = $product->get_id();
            ?>
            <li class="yith-wfbt-item product">
                <div class="wfbt-content-inner">

                    <div class="product-image" data-rel="offeringID_<?php echo $j ?>">
                        <?php echo $product->get_image( 'yith_wfbt_image_size' ); ?>
                        <input type="checkbox" name="offeringID[]" id="offeringID_<?php echo $j ?>" class="active" value="<?php echo $product_id ?>"
                        <?php echo ( ! in_array( $product_id, $unchecked ) && ! $show_unchecked ) ? 'checked="checked"' : '' ?>>
                        <?php if( $j > 0 ) : ?>
                            <div class="image_plus image_plus_<?php echo $j ?>" data-rel="offeringID_<?php echo $j ?>">+</div>
                        <?php endif; ?>
                    </div>

                    <div class="product-title">
                        <a href="<?php echo $product->get_permalink() ?>">
                            <?php echo ( ( $product_id == $main_product_id ) ? __( 'This Product', 'yith-woocommerce-frequently-bought-together' ) . ': ' : '' ) . sprintf( '%1$s %2$s', $product->get_title(), wc_get_formatted_variation( $product, true ) ); ?>
                        </a>
                    </div>
                    <div class="price"><?php echo $product->get_price_html() ?></div>
                </div>
            </li>
            <?php $j++; endforeach; ?>
        </div>
    </ul>
        <div class="yith-wfbt-submit-block">
            <div class="price_text">
                <div class="current-item"> <span class="item">1 Item</span><span class="item-price"></span>
                </div>
                <div class="addons-item"> <span class="items"><span class="addon-count"><?php  echo count($products);?></span> Add-Ons</span><span class="item-price"><span class="woocommerce-Price-amount amount"></span></span></div>
                <div class="items-total"> 
                    <span><?php echo esc_html( $label_total ) ?></span> 
                    <span class="total_price"><?php echo $total ?></span>
                </div> 
            </div>
            <input type="submit" class="yith-wfbt-submit-button button" value="<?php echo esc_html( $label ); ?>">
        </div>
    <input type="hidden" name="yith-wfbt-main-product" value="<?php echo $main_product_id ?>" >
</form>
<script type="text/javascript">
    jQuery(document).ready(function() { 
    jQuery( ".price_text .item-price del" ).remove();
    jQuery( ".price_text .item-price .saved-sale" ).remove();
    });
    var countChecked = function() {
      var n = jQuery( "input:checked" ).length;
      jQuery( ".addon-count" ).text(n - 1);
    };
    countChecked();
     
    jQuery( ".product-image input[type=checkbox]" ).on( "click", countChecked );

    jQuery( ".yith-wfbt-items li .price" ).first().clone().appendTo( ".current-item .item-price" );

    jQuery( ".current-item .item-price del" ).remove();


    var addon = function() {
       var symbol = jQuery( ".total_price .woocommerce-Price-currencySymbol" ).text();
       var a = jQuery('.current-item .woocommerce-Price-amount.amount').text();
       var current = a.substring(1, a.length);

       var t = jQuery('.total_price .woocommerce-Price-amount.amount').text();
       var total = t.substring(1, t.length);

      jQuery( ".addons-item .item-price .woocommerce-Price-amount" ).text(symbol + (parseInt(total - current)));
    };
    addon();
     
    jQuery( ".product-image input[type=checkbox]" ).on( "load", addon );
    jQuery( ".product-image input[type=checkbox]" ).on( "click", addon );


    var disable = function() {
       var symbol = jQuery( ".price_text .addon-count" ).text();
       var test = parseInt(symbol);
       
       if (test == 0) {
        jQuery('.yith-wfbt-submit-block .yith-wfbt-submit-button').prop('disabled',true);
        }else{
        jQuery('.yith-wfbt-submit-block .yith-wfbt-submit-button').prop('disabled',false);
        }
    };
    disable();
     
    jQuery( ".product-image input[type=checkbox]" ).on( "load", disable );
    jQuery( ".product-image input[type=checkbox]" ).on( "click", disable );

</script>
</div>