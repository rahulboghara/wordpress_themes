woocommerce-grid-list-toggle
============================

Adds a grid/list view toggle to product archives in WooCommerce