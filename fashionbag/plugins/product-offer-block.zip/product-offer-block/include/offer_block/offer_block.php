<?php

/**
 * Custom block post
 */

function block_post_type (){
	
	$labels = array(
		'name' => 'Block',
		'singular_name' => 'block',
		'add_new' => 'Add New Block',
		'all_items' => 'All Block',
		'add_new_item' => 'Add Block',
		'edit_item' => 'Edit Block',
		'new_item' => 'New Block',
		'view_item' => 'View Block',
		'search_item' => 'Search Block',
		'not_found' => 'No Block found',
		'not_found_in_trash' => 'No Block found in trash',
		'parent_item_colon' => 'Parent Block'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-text-page',
		'supports' => array(
			'title',
            'editor',
			'thumbnail',
		),
        'menu_position' => 20,
        'exclude_from_search' => false
    );
	register_post_type('block',$args);
}
add_action('init','block_post_type');



function display_block_meta_box( $block ) {
    $block_offer_text = esc_html( get_post_meta( $block->ID, 'block_offer_text', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 200px">Offer Display Text</td>
            <td><input type="text" size="80" name="block_offer_text" value="<?php echo esc_attr($block_offer_text); ?>" required/></td>
        </tr>
    </table>
    <?php
}

function block_pms_admin() {
    add_meta_box( 'block_meta_box',
        'Block Details',
        'display_block_meta_box',
        'block', 'normal', 'high'
    );
}

add_action( 'admin_init', 'block_pms_admin' );


function save_block_fields( $block_id, $block ) {
    // Check post type for block
    if ( $block->post_type == 'block' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['block_offer_text'] ) && $_POST['block_offer_text'] != '' ) {
            update_post_meta( $block_id, 'block_offer_text', $_POST['block_offer_text'] );
        }
    }
}

add_action( 'save_post', 'save_block_fields', 10, 2 );




