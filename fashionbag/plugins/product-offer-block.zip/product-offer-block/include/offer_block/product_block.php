<?php
// First Register the Tab by hooking into the 'woocommerce_product_data_tabs' filter
add_filter( 'woocommerce_product_data_tabs', 'add_product_offer_data_tab' );
function add_product_offer_data_tab( $product_data_tabs ) {
	$product_data_tabs['offer-tab'] = array(
		'label' => __( 'Offers', 'fashionbag' ),
		'target' => 'product_offer_data',
	);
	return $product_data_tabs;
}

add_action( 'woocommerce_product_data_panels', 'add_product_offer_data_fields' );
function add_product_offer_data_fields() {
	global $woocommerce, $post;

	$args = array('post_type' => 'block');
	$query = new WP_Query($args);
	if ($query->have_posts()) {
		$options[''] = __( 'Select a offer', 'woocommerce');
		foreach ($query->posts as $post) {
			$options[$post->ID] = $post->post_title;
		}
	}

	?>
	<!-- id below must match target registered in above add_product_offer_data_tab function -->
	<div id="product_offer_data" class="panel woocommerce_options_panel">
		<?php
		woocommerce_wp_checkbox( array( 
			'id'            => 'show_offer', 
			'wrapper_class' => 'show_if_simple', 
			'label'         => __( 'Show All Offer', 'fashionbag' ),
			'description'   => __( 'Yes', 'fashionbag' ),
			'default'  		=> 'no',
			'desc_tip'    	=> false
		) );

		?>
		<div id="offer_block_1" class="offer_block">
			<?php woocommerce_wp_checkbox( array('id'=> 'show_offer_1','label'=> __( 'Show Offer 1', 'fashionbag' ),'description'=> __( 'Yes', 'fashionbag' ),'default'=> 'no','desc_tip'=> false) ); ?>
			<table class="table">  
				<tr> 
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_title_1') );?></td>
					<td><?php woocommerce_wp_select( array('id' => 'select_offer_1','options' =>  $options) );?></td>
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_condition_1') );?></td>
				</tr>
			</table>
		</div>
		<div id="offer_block_2" class="offer_block">
			<?php woocommerce_wp_checkbox( array('id'=> 'show_offer_2','label'=> __( 'Show Offer 2', 'fashionbag' ),'description'=> __( 'Yes', 'fashionbag' ),'default'=> 'no','desc_tip'=> false) ); ?>
			<table class="table">  
				<tr> 
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_title_2') );?></td>
					<td><?php woocommerce_wp_select( array('id' => 'select_offer_2','options' =>  $options) );?></td>
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_condition_2') );?></td>
				</tr>
			</table>
		</div>
		<div id="offer_block_3" class="offer_block">
			<?php woocommerce_wp_checkbox( array('id'=> 'show_offer_3','label'=> __( 'Show Offer 3', 'fashionbag' ),'description'=> __( 'Yes', 'fashionbag' ),'default'=> 'no','desc_tip'=> false) ); ?>
			<table class="table">  
				<tr> 
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_title_3') );?></td>
					<td><?php woocommerce_wp_select( array('id' => 'select_offer_3','options' =>  $options) );?></td>
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_condition_3') );?></td>
				</tr>
			</table>
		</div>
		<div id="offer_block_4" class="offer_block">
			<?php woocommerce_wp_checkbox( array('id'=> 'show_offer_4','label'=> __( 'Show Offer 4', 'fashionbag' ),'description'=> __( 'Yes', 'fashionbag' ),'default'=> 'no','desc_tip'=> false) ); ?>
			<table class="table">  
				<tr> 
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_title_4') );?></td>
					<td><?php woocommerce_wp_select( array('id' => 'select_offer_4','options' =>  $options) );?></td>
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_condition_4') );?></td>
				</tr>
			</table>
		</div>
		<div id="offer_block_5" class="offer_block">
			<?php woocommerce_wp_checkbox( array('id'=> 'show_offer_5','label'=> __( 'Show Offer 5', 'fashionbag' ),'description'=> __( 'Yes', 'fashionbag' ),'default'=> 'no','desc_tip'=> false) ); ?>
			<table class="table">  
				<tr> 
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_title_5') );?></td>
					<td><?php woocommerce_wp_select( array('id' => 'select_offer_5','options' =>  $options) );?></td>
					<td><?php woocommerce_wp_text_input( array('id'=> 'offer_condition_5') );?></td>
				</tr>
			</table>
		</div>
	</div>
	<?php

}


// Save Fields
add_action( 'woocommerce_process_product_meta', 'offer_fields_save' );
function offer_fields_save( $post_id ){
	if( isset($_POST['offer_title_1']) ){update_post_meta( $post_id, 'offer_title_1', esc_attr( $_POST['offer_title_1'] ) );}
	if( isset($_POST['offer_condition_1']) ){update_post_meta( $post_id, 'offer_condition_1', esc_attr( $_POST['offer_condition_1'] ) );}

	if( isset($_POST['offer_title_2']) ){update_post_meta( $post_id, 'offer_title_2', esc_attr( $_POST['offer_title_2'] ) );}
	if( isset($_POST['offer_condition_2']) ){update_post_meta( $post_id, 'offer_condition_2', esc_attr( $_POST['offer_condition_2'] ) );}

	if( isset($_POST['offer_title_3']) ){update_post_meta( $post_id, 'offer_title_3', esc_attr( $_POST['offer_title_3'] ) );}
	if( isset($_POST['offer_condition_3']) ){update_post_meta( $post_id, 'offer_condition_3', esc_attr( $_POST['offer_condition_3'] ) );}

	if( isset($_POST['offer_title_4']) ){update_post_meta( $post_id, 'offer_title_4', esc_attr( $_POST['offer_title_4'] ) );}
	if( isset($_POST['offer_condition_4']) ){update_post_meta( $post_id, 'offer_condition_4', esc_attr( $_POST['offer_condition_4'] ) );}

	if( isset($_POST['offer_title_5']) ){update_post_meta( $post_id, 'offer_title_5', esc_attr( $_POST['offer_title_5'] ) );}
	if( isset($_POST['offer_condition_5']) ){update_post_meta( $post_id, 'offer_condition_5', esc_attr( $_POST['offer_condition_5'] ) );}


	$woocommerce_select = $_POST['select_offer_1'];
	if( !empty( $woocommerce_select ) ){update_post_meta( $post_id, 'select_offer_1', esc_attr( $woocommerce_select ) );}
	else {update_post_meta( $post_id, 'select_offer_1',  '' );}

	$woocommerce_select = $_POST['select_offer_2'];
	if( !empty( $woocommerce_select ) ){update_post_meta( $post_id, 'select_offer_2', esc_attr( $woocommerce_select ) );}
	else {update_post_meta( $post_id, 'select_offer_2',  '' );}

	$woocommerce_select = $_POST['select_offer_3'];
	if( !empty( $woocommerce_select ) ){update_post_meta( $post_id, 'select_offer_3', esc_attr( $woocommerce_select ) );}
	else {update_post_meta( $post_id, 'select_offer_3',  '' );}

	$woocommerce_select = $_POST['select_offer_4'];
	if( !empty( $woocommerce_select ) ){update_post_meta( $post_id, 'select_offer_4', esc_attr( $woocommerce_select ) );}
	else {update_post_meta( $post_id, 'select_offer_4',  '' );}

	$woocommerce_select = $_POST['select_offer_5'];
	if( !empty( $woocommerce_select ) ){update_post_meta( $post_id, 'select_offer_5', esc_attr( $woocommerce_select ) );}
	else {update_post_meta( $post_id, 'select_offer_5',  '' );}


	if ( isset( $_POST['show_offer'] ) && $_POST['show_offer'] != '' ) {update_post_meta( $post_id, 'show_offer', 'yes' );
	}else{update_post_meta( $post_id, 'show_offer', 'no' );}

	if ( isset( $_POST['show_offer_1'] ) && $_POST['show_offer_1'] != '' ) {update_post_meta( $post_id, 'show_offer_1', 'yes' );
	}else{update_post_meta( $post_id, 'show_offer_1', 'no' );}
	if ( isset( $_POST['show_offer_2'] ) && $_POST['show_offer_2'] != '' ) {update_post_meta( $post_id, 'show_offer_2', 'yes' );
	}else{update_post_meta( $post_id, 'show_offer_2', 'no' );}
	if ( isset( $_POST['show_offer_3'] ) && $_POST['show_offer_3'] != '' ) {update_post_meta( $post_id, 'show_offer_3', 'yes' );
	}else{update_post_meta( $post_id, 'show_offer_3', 'no' );}
	if ( isset( $_POST['show_offer_4'] ) && $_POST['show_offer_5'] != '' ) {update_post_meta( $post_id, 'show_offer_4', 'yes' );
	}else{update_post_meta( $post_id, 'show_offer_4', 'no' );}
	if ( isset( $_POST['show_offer_5'] ) && $_POST['show_offer_5'] != '' ) {update_post_meta( $post_id, 'show_offer_5', 'yes' );
	}else{update_post_meta( $post_id, 'show_offer_5', 'no' );}
}


function offer_product_tab_content() {
	global $post;

	$show_offer = get_post_meta( $post->ID, 'show_offer', true );
	$show_offer_1 = get_post_meta( $post->ID, 'show_offer_1', true );
	$show_offer_2 = get_post_meta( $post->ID, 'show_offer_2', true );
	$show_offer_4 = get_post_meta( $post->ID, 'show_offer_4', true );
	$show_offer_3 = get_post_meta( $post->ID, 'show_offer_3', true );
	$show_offer_5 = get_post_meta( $post->ID, 'show_offer_5', true );

	$offer_title_1 = get_post_meta( $post->ID, 'offer_title_1', true );
	$offer_title_2 = get_post_meta( $post->ID, 'offer_title_2', true );
	$offer_title_3 = get_post_meta( $post->ID, 'offer_title_3', true );
	$offer_title_4 = get_post_meta( $post->ID, 'offer_title_4', true );
	$offer_title_5 = get_post_meta( $post->ID, 'offer_title_5', true );


	$select_offer_1 = get_post_meta( $post->ID, 'select_offer_1', true );
	$select_offer_2 = get_post_meta( $post->ID, 'select_offer_2', true );
	$select_offer_3 = get_post_meta( $post->ID, 'select_offer_3', true );
	$select_offer_4 = get_post_meta( $post->ID, 'select_offer_4', true );
	$select_offer_5 = get_post_meta( $post->ID, 'select_offer_5', true );

	$block_offer_text_1 = get_post_meta( $post->ID, 'block_offer_text_1', true );
	$block_offer_text_2 = get_post_meta( $post->ID, 'block_offer_text_2', true );
	$block_offer_text_3 = get_post_meta( $post->ID, 'block_offer_text_3', true );
	$block_offer_text_4 = get_post_meta( $post->ID, 'block_offer_text_4', true );
	$block_offer_text_5 = get_post_meta( $post->ID, 'block_offer_text_5', true );

	$offer_condition_1 = get_post_meta( $post->ID, 'offer_condition_1', true );
	$offer_condition_2 = get_post_meta( $post->ID, 'offer_condition_2', true );
	$offer_condition_3 = get_post_meta( $post->ID, 'offer_condition_3', true );
	$offer_condition_4 = get_post_meta( $post->ID, 'offer_condition_4', true );
	$offer_condition_5 = get_post_meta( $post->ID, 'offer_condition_5', true );

	if ( $show_offer == 'yes' ) {
		
			?>
			<div class="product-offer"> 
				<ul class="product-offers-list">
					<?php
					if ( $show_offer_1 == 'yes' ) {
						if ( ! empty( $select_offer_1 ) ) {
					?>
					<li class="product-offer-item">
						<strong><?php echo esc_attr($offer_title_1); ?></strong>
						<span class="offer_title"><?php echo get_post_field('block_offer_text', $select_offer_1); ?></span>
						<span class="offer_condition"><span><?php echo esc_attr($offer_condition_1); ?></span><div class="offer-content" style="display: none;"><div class="offer_content_header"><span class="fb-close">X</span><h5>Terms and Condition</h5></div><?php echo apply_filters('the_content', get_post_field('post_content', $select_offer_1)); ?></div></span>
					</li>
					<?php
					}
					}
					if ( $show_offer_2 == 'yes' ) {
						if ( ! empty( $select_offer_2 ) ) {
					?>
					<li class="product-offer-item">
						<strong><?php echo esc_attr($offer_title_2); ?></strong>
						<span class="offer_title"><?php echo get_post_field('block_offer_text', $select_offer_2); ?></span>
						<span class="offer_condition"><span><?php echo esc_attr($offer_condition_2); ?></span><div class="offer-content" style="display: none;"><div class="offer_content_header"><span class="fb-close">X</span><h5>Terms and Condition</h5></div><?php echo apply_filters('the_content', get_post_field('post_content', $select_offer_2)); ?></div></span>
					</li>
					<?php
					}
				}
					if ( $show_offer_3 == 'yes' ) {
						if ( ! empty( $select_offer_3 ) ) {
					?>
					<li class="product-offer-item">
						<strong><?php echo esc_attr($offer_title_3); ?></strong>
						<span class="offer_title"><?php echo get_post_field('block_offer_text', $select_offer_3); ?></span>
						<span class="offer_condition"><span><?php echo esc_attr($offer_condition_3); ?></span><div class="offer-content" style="display: none;"><div class="offer_content_header"><span class="fb-close">X</span><h5>Terms and Condition</h5></div><?php echo apply_filters('the_content', get_post_field('post_content', $select_offer_3)); ?></div></span>
					</li>
					<?php
					}
				}
					if ( $show_offer_4 == 'yes' ) {
						if ( ! empty( $select_offer_4 ) ) {
					?>
					<li class="product-offer-item">
						<strong><?php echo esc_attr($offer_title_4); ?></strong>
						<span class="offer_title"><?php echo get_post_field('block_offer_text', $select_offer_4); ?></span>
						<span class="offer_condition"><span><?php echo esc_attr($offer_condition_4); ?></span><div class="offer-content" style="display: none;"><div class="offer_content_header"><span class="fb-close">X</span><h5>Terms and Condition</h5></div><?php echo apply_filters('the_content', get_post_field('post_content', $select_offer_4)); ?></div></span>
					</li>
					<?php
					}
				}
					if ( $show_offer_5 == 'yes' ) {
						if ( ! empty( $select_offer_5 ) ) {
					?>
					<li class="product-offer-item">
						<strong><?php echo esc_attr($offer_title_5); ?></strong>
						<span class="offer_title"><?php echo get_post_field('block_offer_text', $select_offer_5); ?></span>
						<span class="offer_condition"><span><?php echo esc_attr($offer_condition_5); ?></span><div class="offer-content" style="display: none;"><div class="offer_content_header"><span class="fb-close">X</span><h5>Terms and Condition</h5></div><?php echo apply_filters('the_content', get_post_field('post_content', $select_offer_5)); ?></div></span>
					</li>
					<?php
					}
				}
					?>
				</ul>
			</div>
			<?php
		}
	
}

add_action( 'woocommerce_single_product_summary', 'offer_product_tab_content', 16 );


add_action( 'wp_footer', 'ajax_fetch' );
function ajax_fetch() {
	?>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			jQuery(".product-offers-list .product-offer-item .offer_condition").click(function(event){
			   event.stopPropagation();
			   var $this = jQuery(this).closest('.product-offers-list .product-offer-item').find('.offer-content');
		       $this.fadeToggle('slow');
		       jQuery('.offer-content').not($this).fadeOut('slow');
		       
			});

			jQuery(document).click(function (e) {
			    if (!jQuery(e.target).closest('.offer-content').length)
			    {
			        jQuery('.offer-content').fadeOut();
			    }
			});
		});

	</script>

	<?php
}
