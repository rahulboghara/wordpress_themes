<?php
/*
Plugin Name: Product Offer Block
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying Product Offer Block.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 *  Product Offer Block
 */

if ( ! defined( 'ABSPATH' ) ) die( 'Accessing this file directly is denied.' );

if (!class_exists('product_ob')){
    class product_ob{

        public function __construct()
        {   
        	$this->_define_constant();
            // now lets include all the required files
            $this->_include();
        }

		private function _define_constant()
        {
            if( ! defined( 'product_ob_path' ) ) define( 'product_ob_path', plugin_dir_path( __FILE__ ) );
        }

		private function _include()
        {
			require product_ob_path . 'include/offer_block/offer_block.php';
			require product_ob_path . 'include/offer_block/product_block.php';

		}
    }
}
new product_ob();



