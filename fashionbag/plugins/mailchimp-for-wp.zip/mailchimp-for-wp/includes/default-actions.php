<?php

defined('ABSPATH') or exit;

add_action('mc4wp_refresh_mailchimp_lists', 'mc4wp_refresh_mailchimp_lists');
