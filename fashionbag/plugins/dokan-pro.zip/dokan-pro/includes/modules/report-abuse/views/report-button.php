<style>
    .dokan-report-abuse-button {
        display: inline-block;
        color: inherit;
        margin-top: 5px;
        font-size: 0.8em;
    }

    .dokan-report-abuse-button.working {
        opacity: 0.8;
    }
</style>

<a href="#report-abuse" class="dokan-report-abuse-button">
    <i class="fa fa-flag"></i> <?php echo esc_html( $label ); ?>
</a>
