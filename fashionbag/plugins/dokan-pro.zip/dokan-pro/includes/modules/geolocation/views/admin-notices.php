<div id="message" class="error notice is-dismissible">
    <p><?php _e( '<strong>Dokan Geolocation Module</strong> requires Google Map API Key. Please set your API Key in <strong>Dokan Admin Settings > Appearance > Google Map API Key</strong>.', 'dokan' ); ?></p>
</div>
