<?php

include_once DOKAN_LIB_DIR.'/class.taxonomy-walker.php';

class Dokan_Walker_Tag_Multi extends DokanTaxonomyWalker {

}

