<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

    <div id="lvca-infobox">
        <div class="lvca-info-overlay"></div>
        <div class="lvca-info-inner">
            <div class="lvca-infobox-msg"></div>
        </div>
    </div>

</div><!-- lvca-wrap -->