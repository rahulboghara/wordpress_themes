<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div id="lvca-banner-wrap">

    <div id="lvca-banner" class="lvca-banner-sticky">
        <h2><span><?php echo __('WPBakery Page Builder Addons', 'livemesh-vc-addons'); ?></span><?php echo __('Plugin Documentation', 'livemesh-vc-addons') ?></h2>
    </div>

</div>