jQuery(function ($) {

    $(".lvca-date_picker-wrap .lvca_date_picker").datepicker({
        dateFormat: "yy/mm/dd",
    });

});