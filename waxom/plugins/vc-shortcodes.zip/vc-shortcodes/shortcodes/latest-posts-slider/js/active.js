/* breaking news */
jQuery(document).ready(function( $ ) {
    
    $('.break-news-slider').slick({
        dots: false,
        arrows: true,
        vertical: true,
        slidesToShow: 1,
        touchMove: true,
        slidesToScroll: 1,
        autoplay:true
    });

});
