import {CarouselSlider} from "./CarouselSlider";

new CarouselSlider(jQuery);
