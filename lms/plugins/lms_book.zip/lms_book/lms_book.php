<?php
/*
Plugin Name: Book Lms
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying Book Lms.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 * Custom book post
 */

function book_post_type (){
	
	$labels = array(
		'name' => 'Books',
		'singular_name' => 'books',
		'add_new' => 'Add New',
		'all_items' => 'All Books',
		'add_new_item' => 'Add Books',
		'edit_item' => 'Edit Books',
		'new_item' => 'New Books',
		'view_item' => 'View Items',
		'search_item' => 'Search Items Books',
		'not_found' => 'No Items found',
		'not_found_in_trash' => 'No Books found in trash',
		'parent_item_colon' => 'Parent Books'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-video-alt',
		'supports' => array(
			'title',
			'editor',
			'thumbnail',
			'revisions', 
		),
        'taxonomies' => array('book_category'),
		'menu_position' => 15,
		'exclude_from_search' => false
	);
	register_post_type('book',$args);
    book_register_taxonomies();
}
add_action('init','book_post_type');



//Register Taxonomies
function book_register_taxonomies() {
    register_taxonomy('book_category', 'book', array('hierarchical' => true, 'label' => 'Books Category','show_admin_column' => true, 'query_var' => true, 'rewrite' => array('slug' => 'book-type')));
    if (count(get_terms('book_category', 'hide_empty=0')) == 0) {
        register_taxonomy('type', 'book', array('hierarchical' => true, 'label' => 'Books Type'));
        $_categories = get_categories('taxonomy=type&title_li=');
        foreach ($_categories as $_cat) {
            if (!term_exists($_cat->name, 'book_category'))
                wp_insert_term($_cat->name, 'book_category');
        }
        $book = new WP_Query(array('post_type' => 'book', 'posts_per_page' => '-1'));
        while ($book->have_posts()) : $book->the_post();
            $post_id = get_the_ID();
            $_terms = wp_get_post_terms($post_id, 'type');
            $terms = array();
            foreach ($_terms as $_term) {
                $terms[] = $_term->term_id;
            }
            wp_set_post_terms($post_id, $terms, 'book_category');
        endwhile;
        wp_reset_query();
        register_taxonomy('type', array());
    } 
}


function book_scripts() {

wp_enqueue_script( 'jquery-ui-datepicker' );
wp_enqueue_style( 'jquery-ui-style', '//ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/smoothness/jquery-ui.css', true);
wp_enqueue_script( 'datepicker', plugin_dir_url( __FILE__ ) . '/js/datepiker.js', array(), '', true );
}
add_action( 'admin_enqueue_scripts', 'book_scripts' );


function display_book_meta_box( $book ) {
	$book_id = esc_html( get_post_meta( $book->ID, 'book_id', true ) );
    $book_author = esc_html( get_post_meta( $book->ID, 'book_author', true ) );
    $book_pb_date = esc_html( get_post_meta( $book->ID, 'book_pb_date', true ) );
    ?>
    <table>
    	<tr>
            <td style="width: 100%">Book Id</td>
            <td><input type="text" size="80" name="book_id_name" value="<?php echo esc_attr($book_id); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Book Author</td>
            <td><input type="text" size="80" name="book_author_name" value="<?php echo esc_attr($book_author); ?>" /></td>
        </tr>
        <tr>
            <td style="width: 100%">Book Published On</td>
            <td><input type="text" size="80" id="book_pb_date" name="book_pb_date_name" value="<?php echo esc_attr($book_pb_date); ?>" /></td>
        </tr>
    </table>
    <?php
}

function lms_admin() {
    add_meta_box( 'book_meta_box',
        'Book Details',
        'display_book_meta_box',
        'book', 'normal', 'high'
    );
}

add_action( 'admin_init', 'lms_admin' );


function save_book_fields( $book_id, $book ) {
    // Check post type for Books
    if ( $book->post_type == 'book' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['book_id_name'] ) && $_POST['book_id_name'] != '' ) {
            update_post_meta( $book_id, 'book_id', $_POST['book_id_name'] );
        }
        if ( isset( $_POST['book_author_name'] ) && $_POST['book_author_name'] != '' ) {
            update_post_meta( $book_id, 'book_author', $_POST['book_author_name'] );
        }
        if ( isset( $_POST['book_pb_date_name'] ) && $_POST['book_pb_date_name'] != '' ) {
            update_post_meta( $book_id, 'book_pb_date', $_POST['book_pb_date_name'] );
        }
    }
}

add_action( 'save_post', 'save_book_fields', 10, 2 );


