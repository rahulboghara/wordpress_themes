jQuery(document).ready(function(){
jQuery('#book_pb_date').datepicker({
dateFormat : 'dd-mm-yy'
});
});