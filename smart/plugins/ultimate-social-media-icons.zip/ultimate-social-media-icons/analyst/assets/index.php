<?php
	// Silence is golden.
