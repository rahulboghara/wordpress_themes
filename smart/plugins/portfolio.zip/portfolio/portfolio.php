<?php
/*
Plugin Name: Portfolio
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying portfolio.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 * Custom portfolio post
 */

function portfolio_post_type (){
	
	$labels = array(
		'name' => 'PortFolio',
		'singular_name' => 'PortFolio',
		'add_new' => 'Add New',
		'all_items' => 'All Item',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit Item',
		'new_item' => 'New Item',
		'view_item' => 'View Items',
		'search_item' => 'Search Items PortFolio',
		'not_found' => 'No Items found',
		'not_found_in_trash' => 'No Item found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-video-alt',
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions',
			'author',
			'comments', 
			'revisions', 
			'custom-fields',
			'discussion',
		),
		'taxonomies' => array('portfolio_category'),
		'menu_position' => 15,
		'exclude_from_search' => false
	);
	register_post_type('Portfolio',$args);
	smart_portfolio_register_taxonomies();
}
add_action('init','portfolio_post_type');



//Register Taxonomies
function smart_portfolio_register_taxonomies() {
    register_taxonomy('portfolio_category', 'portfolio', array('hierarchical' => true, 'label' => 'Portfolio Category','show_admin_column' => true, 'query_var' => true, 'rewrite' => array('slug' => 'portfolio-type')));
     if (count(get_terms('portfolio_category', 'hide_empty=0')) == 0) {
        register_taxonomy('type', 'portfolio', array('hierarchical' => true, 'label' => 'Item Type'));
        $_categories = get_categories('taxonomy=type&title_li=');
        foreach ($_categories as $_cat) {
            if (!term_exists($_cat->name, 'portfolio_category'))
                wp_insert_term($_cat->name, 'portfolio_category');
        }
        $portfolio = new WP_Query(array('post_type' => 'portfolio', 'posts_per_page' => '-1'));
        while ($portfolio->have_posts()) : $portfolio->the_post();
            $post_id = get_the_ID();
            $_terms = wp_get_post_terms($post_id, 'type');
            $terms = array();
            foreach ($_terms as $_term) {
                $terms[] = $_term->term_id;
            }
            wp_set_post_terms($post_id, $terms, 'portfolio_category');
        endwhile;
        wp_reset_query();
        register_taxonomy('type', array());
    } 
}


