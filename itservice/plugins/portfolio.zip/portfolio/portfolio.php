<?php
/*
Plugin Name: Gallery Portfolio
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying Gallery Portfolio.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 * Custom Gallery Portfolio post
 */

function gallery_portfolio (){
	
	$labels = array(
		'name' => 'Gallery Portfolio',
		'singular_name' => 'gallery_portfolio',
		'add_new' => 'Add New',
		'all_items' => 'All Item',
		'add_new_item' => 'Add Item',
		'edit_item' => 'Edit Item',
		'new_item' => 'New Item',
		'view_item' => 'View Items',
		'search_item' => 'Search Items PortFolio',
		'not_found' => 'No Items found',
		'not_found_in_trash' => 'No Item found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-images-alt2',
		'supports' => array(
			'title',
			'editor',
			'thumbnail',
		),
		'menu_position' => 15,
	);
	register_post_type('gallery_portfolio',$args);
}
add_action('init','gallery_portfolio');



function display_portfolio_meta_box( $portfolio ) {
    $portfolio_url = esc_html( get_post_meta( $portfolio->ID, 'portfolio_url', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 200px">Enter URL</td>
            <td><input type="text" size="80" name="portfolio_url" value="<?php echo esc_attr($portfolio_url); ?>"/></td>
        </tr>
    </table>
    <?php
}

function block_portfolio_admin() {
    add_meta_box( 'portfolio_meta_box',
        'Gallery Portfolio Details',
        'display_portfolio_meta_box',
        'gallery_portfolio', 'normal', 'high'
    );
}

add_action( 'admin_init', 'block_portfolio_admin' );


function save_portfolio_fields( $portfolio_id, $portfolio ) {
    // Check post type for portfolio
    if ( $portfolio->post_type == 'gallery_portfolio' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['portfolio_url'] ) && $_POST['portfolio_url'] != '' ) {
            update_post_meta( $portfolio_id, 'portfolio_url', $_POST['portfolio_url'] );
        }
    }
}

add_action( 'save_post', 'save_portfolio_fields', 10, 2 );


