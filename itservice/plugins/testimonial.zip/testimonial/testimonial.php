<?php
/*
Plugin Name: Testimonial
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying Testimonial.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 * Custom Testimonial post
 */

function testimonial (){
	
	$labels = array(
		'name' => 'Testimonial',
		'singular_name' => 'testimonial',
		'add_new' => 'Add New Testimonial',
		'all_items' => 'All Testimonial',
		'add_new_item' => 'Add Testimonial',
		'edit_item' => 'Edit Testimonial',
		'new_item' => 'New Testimonial',
		'view_item' => 'View Testimonials',
		'search_item' => 'Search Testimonials',
		'not_found' => 'No Testimonials found',
		'not_found_in_trash' => 'No Testimonial found in trash',
		'parent_item_colon' => 'Parent Testimonial'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-groups',
		'supports' => array(
			'title',
			'editor',
			'thumbnail',
		),
		'menu_position' => 15,
	);
	register_post_type('testimonial',$args);
}
add_action('init','testimonial');



function display_testimonial_meta_box( $testimonial ) {
    $test_designation = esc_html( get_post_meta( $testimonial->ID, 'test_designation', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 200px">Enter Designation</td>
            <td><input type="text" size="80" name="test_designation" value="<?php echo esc_attr($test_designation); ?>"/></td>
        </tr>
    </table>
    <?php
}

function block_testimonial_admin() {
    add_meta_box( 'testimonial_meta_box',
        'Testimonial Details',
        'display_testimonial_meta_box',
        'testimonial', 'normal', 'high'
    );
}

add_action( 'admin_init', 'block_testimonial_admin' );


function save_testimonial_fields( $testimonial_id, $testimonial ) {
    // Check post type for testimonial
    if ( $testimonial->post_type == 'testimonial' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['test_designation'] ) && $_POST['test_designation'] != '' ) {
            update_post_meta( $testimonial_id, 'test_designation', $_POST['test_designation'] );
        }
    }
}

add_action( 'save_post', 'save_testimonial_fields', 10, 2 );


