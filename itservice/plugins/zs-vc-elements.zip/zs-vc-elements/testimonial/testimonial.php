<?php
/*
Element Description: Zs Testimonial
*/

// Element Class 
class vcTestimonial extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'vc_testimonial_mapping' ) );
        add_shortcode( 'vc_testimonial', array( $this, 'vc_testimonial_html' ) );
    }

        // Element Mapping
    public function vc_testimonial_mapping() {
        vc_map( array(
            'name' => __( 'Zs Testimonial', 'zs' ),
            'base' => 'vc_testimonial',
            'icon' => plugin_dir_url( __DIR__ ). "public/img/icon.png",
            'category' => __( 'Zs Element', 'zs' ),
            'description' => __( 'Display Testimonial', 'zs' ),
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Slides per view', 'zs' ),
                    'param_name' => 'test_per_view',
                    'default' => '3',
                    'description' => __( 'Set numbers of slides you want to display at the same time on slider\'s container for carousel mode.', 'zs' ),
                    'save_always' => true,
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Element Class', 'zs' ),
                    'param_name' => 'test_class',
                    'description' => __( 'Add Element Class', 'zs' ),
                ),
            )
        ) );                             

    }


    

        // Element HTML
    public function vc_testimonial_html( $atts ) {
     extract(
        shortcode_atts(
            array(
                'test_per_view'      => '3',
                'test_class' => '',
            ), 
            $atts
        )
    );

     $testimonial = 'testimonial-' . rand( 100, 999 );



     $args = new WP_Query( array(
      'post_type' => 'testimonial',
      'post_status' => 'publish',
      'order' => 'ASC',
      'posts_per_page' => '-1'
  ));
     ob_start();
     if($args->have_posts()) {
        $i = 1;
        ?>
        <div id="<?php echo esc_attr( $testimonial ); ?>" class="">
            <?php
            while($args->have_posts()) { $args->the_post(); 
               $test_designation = esc_html( get_post_meta( get_the_ID(), 'test_designation', true ) );
               ?>
               <div class="test_container">
                <div class="img_container">
                    <div class="test-image"><?php the_post_thumbnail('testimonial'); ?></div>
                    <?php
                    if ( ! empty( get_the_content() ) ) {
                        ?>
                        <div class="test-text">
                            <div class="test-text-bg custom-scroll">
                              <?php the_content(); ?>
                          </div>
                      </div>
                      <?php
                  }                    
                  ?> 
              </div>
              <div class="test-info">
                <p><?php the_title(); ?></p>
                <?php
                if ( ! empty( $test_designation ) ) {
                    ?>
                    <p>(<?php echo $test_designation; ?>)</p>
                    <?php
                }
                ?>
            </div>
        </div>
        <?php
        $i++;
    }

    ?>
</div>
<script rel="text/javascript">
    jQuery(document).ready(function(){
        jQuery('#<?php echo esc_attr( $testimonial ); ?>').slick({
            infinite: true,
            speed: 300,
            slidesToShow: <?php echo esc_attr($test_per_view); ?>,
            slidesToScroll: <?php echo esc_attr($test_per_view); ?>,
            responsive: [{
                breakpoint: 1025,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            ]
        });

    });
</script>
<?php
$i++;
}


return ob_get_clean();
} // End Element Class

}
// Element Class Init
new vcTestimonial();  
?>