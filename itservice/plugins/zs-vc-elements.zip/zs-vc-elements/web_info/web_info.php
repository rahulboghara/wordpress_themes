<?php
/*
Element Description: Zs Web Info
*/

// Element Class 
class ZSWebInfo extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'vc_web_info_mapping' ) );
        add_shortcode( 'vc_web_info', array( $this, 'vc_web_info_html' ) );
    }

        // Element Mapping
    public function vc_web_info_mapping() {
        vc_map( array(
            'name' => __( 'Zs Web Info', 'zs' ),
            'base' => 'vc_web_info',
            'icon' => plugin_dir_url( __DIR__ ). "public/img/icon.png",
            'category' => __( 'Zs Element', 'zs' ),
            'description' => __( 'Display Web Info', 'zs' ),

            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Web Block No.', 'zs' ),
                    'save_always' => true,
                    'param_name' => 'btn_web_no',
                    'description' => __( 'Add Web Block No. Same As This Button Click To Open Web Block', 'zs' ),
                    'admin_label' => true,
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Web Info Title', 'zs' ),
                    'save_always' => true,
                    'param_name' => 'btn_title',
                    'description' => __( 'Add Web Info Title', 'zs' ),
                    'admin_label' => true,
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Web Info Description', 'zs' ),
                    'save_always' => true,
                    'param_name' => 'btn_desc',
                    'description' => __( 'Add Web Info Description', 'zs' ),
                ),

                array(
                    'type' => 'textfield',
                    'heading' => __( 'Element Class', 'zs' ),
                    'param_name' => 'pc_class',
                    'description' => __( 'Add Element Class', 'zs' ),
                ),


            )
        ) );                             

}

// Element HTML
public function vc_web_info_html( $atts ) {
    // Params extraction

    extract(
        shortcode_atts(
            array(
                'btn_web_no' => '',
                'btn_title' => '',
                'btn_desc'  => '',
                'pc_class' => ''
            ), 
            $atts
        )
    );
    $html = '
    <div class="'. esc_attr( $pc_class ) .'">
    <button class="md-trigger" data-modal="devel-modal-'. esc_attr($btn_web_no) .'"> 
        <p class="btn_title">' . esc_attr($btn_title) . '</p>
        <p class="btn_desc">' . esc_attr($btn_desc) . '</p>
    </button>

    </div>';      
     
    return $html;
return ob_get_clean();
}

} // End Element Class

// Element Class Init
new ZSWebInfo();  
?>