<?php
/*
Element Description: Zs Gallery Slider
*/

// Element Class 
class vcGallerySlider extends WPBakeryShortCode {

    // Element Init
    function __construct() {
        add_action( 'init', array( $this, 'vc_gallery_slider_mapping' ) );
        add_shortcode( 'vc_gallery_slider', array( $this, 'vc_gallery_slider_html' ) );
    }

        // Element Mapping
    public function vc_gallery_slider_mapping() {
        vc_map( array(
            'name' => __( 'Zs Gallery Slider', 'zs' ),
            'base' => 'vc_gallery_slider',
            'icon' => plugin_dir_url( __DIR__ ). "public/img/icon.png",
            'category' => __( 'Zs Element', 'zs' ),
            'description' => __( 'Display Gallery Slider', 'zs' ),
            'params' => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Slides per view', 'zs' ),
                    'param_name' => 'slides_per_view',
                    'default' => '3',
                    'description' => __( 'Set numbers of slides you want to display at the same time on slider\'s container for carousel mode.', 'zs' ),
                    'save_always' => true,
                ),
                array(
                    'type' => 'textfield',
                    'heading' => __( 'Element Class', 'zs' ),
                    'param_name' => 'slide_class',
                    'description' => __( 'Add Element Class', 'zs' ),
                ),
            )
        ) );                             

    }


    

        // Element HTML
    public function vc_gallery_slider_html( $atts ) {
       extract(
        shortcode_atts(
            array(
                'slides_per_view'      => '3',
                'slide_class' => '',
            ), 
            $atts
        )
    );

       $gallery_slider = 'gallery_slider-' . rand( 100, 999 );

       $args = new WP_Query( array(
          'post_type' => 'gallery_portfolio',
          'post_status' => 'publish',
          'order' => 'ASC',
          'posts_per_page' => '-1'
      ));
       ob_start();
       if($args->have_posts()) {
        $i = 1;
        ?>
        <div id="<?php echo esc_attr( $gallery_slider ); ?>" class="<?php echo esc_attr( $slide_class ); ?>">
        <?php
          while($args->have_posts()) { $args->the_post(); 
             $portfolio_url = esc_html( get_post_meta( get_the_ID(), 'portfolio_url', true ) );
              ?>
              <div class="gallery_container">
                <div class="img_container">
                    <div class="gallery-image"><?php the_post_thumbnail('gallery_slider'); ?></div>
                    <?php
                    if ( ! empty( get_the_content() ) ) {
                        ?>
                    <div class="gallery-text">
                        <div class="gallery-text-bg custom-scroll">
                          <?php the_content(); ?>
                        </div>
                      </div>
                      <?php
                        }else{
                            ?>
                            <a class="md-trigger" data-modal="gallery-modal-<?php echo $i; ?>" tabindex="0"></a>
                            <?php
                        }
                    ?> 
                </div>
                <div class="links-info">
                    <button class="md-trigger" data-modal="gallery-modal-<?php echo $i; ?>" tabindex="0"></button>
                    <?php
                    if ( ! empty( $portfolio_url ) ) {
                        ?>
                    <a href="<?php echo esc_html( get_post_meta( get_the_ID(), 'portfolio_url', true ) ); ?>" target="_blank"><?php the_title(); ?></a>
                        <?php
                        }
                    ?> 
                </div>
            </div>
            <?php
            $i++;
        }

        ?>
        </div>
        <script rel="text/javascript">
                jQuery(document).ready(function(){
                    jQuery('#<?php echo esc_attr( $gallery_slider ); ?>').slick({
                        infinite: true,
                        speed: 300,
                        slidesToShow: <?php echo esc_attr($slides_per_view); ?>,
                        slidesToScroll: <?php echo esc_attr($slides_per_view); ?>,
                        responsive: [{
                                    breakpoint: 1025,
                                    settings: {
                                        slidesToShow: 2,
                                        slidesToScroll: 2
                                    }
                                },
                                {
                                    breakpoint: 768,
                                    settings: {
                                        slidesToShow: 1,
                                        slidesToScroll: 1
                                    }
                                },
                                {
                                    breakpoint: 480,
                                    settings: {
                                        slidesToShow: 1,
                                        slidesToScroll: 1
                                    }
                                }
                            ]
                        });

                });
            </script>
        <?php
        $i++;
    }


return ob_get_clean();
} // End Element Class

}
// Element Class Init
new vcGallerySlider();  
?>