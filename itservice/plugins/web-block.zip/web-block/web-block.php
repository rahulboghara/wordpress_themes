<?php
/*
Plugin Name: Web Development Block
Plugin URI: https://www.zitronesolutions.com/
Description: Declares a plugin that will create a custom post type displaying Web Development Block.
Version: 1.0
Author: Zitrone Solutions
Author URI: https://www.zitronesolutions.com/
License: GPLv2
*/

/**
 * Custom Web Development Block post
 */

function web_block (){
	
	$labels = array(
		'name' => 'Web Block',
		'singular_name' => 'web-block',
		'add_new' => 'Add New Web Block',
		'all_items' => 'All Web Block',
		'add_new_item' => 'Add Web Block',
		'edit_item' => 'Edit Web Block',
		'new_item' => 'New Web Block',
		'view_item' => 'View Web Blocks',
		'search_item' => 'Search Web Blocks',
		'not_found' => 'No Web Blocks found',
		'not_found_in_trash' => 'No Web Block found in trash',
		'parent_item_colon' => 'Parent Web Block'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'menu_icon' => 'dashicons-format-aside',
		'supports' => array(
			'title',
			'editor',
		),
		'menu_position' => 15,
	);
	register_post_type('web_block',$args);
}
add_action('init','web_block');



function display_web_block_meta_box( $web_block ) {
    $web_block_number = esc_html( get_post_meta( $web_block->ID, 'web_block_number', true ) );
    ?>
    <table>
        <tr>
            <td style="width: 200px">Enter Web Block No.</td>
            <td><input type="number" size="80" name="web_block_number" value="<?php echo esc_attr($web_block_number); ?>" required/></td>
        </tr>
    </table>
    <?php
}

function block_web_block_admin() {
    add_meta_box( 'web_block_meta_box',
        'Web Block Details',
        'display_web_block_meta_box',
        'web_block', 'normal', 'high'
    );
}

add_action( 'admin_init', 'block_web_block_admin' );


function save_web_block_fields( $web_block_id, $web_block ) {
    // Check post type for web_block
    if ( $web_block->post_type == 'web_block' ) {
        // Store data in post meta table if present in post data
        if ( isset( $_POST['web_block_number'] ) && $_POST['web_block_number'] != '' ) {
            update_post_meta( $web_block_id, 'web_block_number', $_POST['web_block_number'] );
        }
    }
}

add_action( 'save_post', 'save_web_block_fields', 10, 2 );



function add_web_block_columns($columns) {
    return array_merge($columns,
              array('web_block_number' => __('Web Block No.')));
}
add_filter('manage_web_block_posts_columns' , 'add_web_block_columns');


function custom_web_block_column( $column ) {
    global $post;
    switch ( $column ) {
      case 'web_block_number':
        echo get_post_meta( $post->ID , 'web_block_number' , true );
        break;
    }
}
add_action( 'manage_web_block_posts_custom_column' , 'custom_web_block_column', 10, 2);


// Register the column as sortable
function register_sortable_columns( $columns ) {
    $columns['web_block_number'] = 'Web Block No.';
    return $columns;
}
add_filter( 'manage_edit-web_block_sortable_columns', 'register_sortable_columns' );
